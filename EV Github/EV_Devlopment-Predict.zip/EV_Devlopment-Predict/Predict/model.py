import pandas as pd
from statsmodels.tsa.arima.model import ARIMA
import pickle

# Load the data from the CSV file
csv_file_path = csv_file_path = r'C:\asbuilt\BMS_Predction\sample_data_2023.csv'
 # Replace with the actual path to your CSV file
df = pd.read_csv(csv_file_path, parse_dates=['Date'])
df.set_index('Date', inplace=True)

# Train the ARIMA model
model = ARIMA(df['Distance_Traveled'], order=(1, 1, 1))
model_fit = model.fit()

# Save the model to a file
model_file_path = 'arima_model.pkl'
with open(model_file_path, 'wb') as model_file:
    pickle.dump(model_fit, model_file)

print(f"Model saved to {model_file_path}")
