import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

file_path = r'C:\asbuilt\BMS_Predction\ev_battery_vs_distance.csv'
df = pd.read_csv(file_path)

print(df.head(10))

print(df.shape)

print(df.columns)
X = df[['BATT_LEVEL', 'RANGE_EST']]

print(X.sample(10))

plt.figure(figsize=(12, 10))

plt.scatter(X['BATT_LEVEL'], X['RANGE_EST'], s=100, color='blue')

plt.ylabel("Distance Estd")
plt.xlabel("Battery Level")

plt.show()
from sklearn.covariance import EllipticEnvelope

ee = EllipticEnvelope(support_fraction=None, contamination=0.1)
y_pred = ee.fit_predict(X)

print(y_pred)

n_outliers = (y_pred == -1).sum()
n_outliers
print(n_outliers)


xx, yy = np.meshgrid(np.linspace(X['BATT_LEVEL'].min(), X['BATT_LEVEL'].max(), 500),
                     np.linspace(X['RANGE_EST'].min(), X['RANGE_EST'].max(), 500))

Z = ee.predict(np.c_[xx.ravel(), yy.ravel()])
Z = Z.reshape(xx.shape)
plt.figure(figsize=(12, 10))

plt.title('EllipticEnvelope', size=18)

colors = np.array(['r', 'b'])

plt.scatter(X['BATT_LEVEL'], 
            X['RANGE_EST'], 
            s=100, 
            color=colors[(y_pred + 1) // 2])

plt.contour(xx, yy, Z, levels=[0], linewidths=2, colors='black')

plt.show()


from sklearn.ensemble import IsolationForest

#isf =  IsolationForest(behaviour='new', contamination=0.08)
isf =  IsolationForest( contamination=0.08)
y_pred = isf.fit_predict(X)

y_pred


n_outliers = (y_pred == -1).sum()
n_outliers

print(n_outliers)

xx, yy = np.meshgrid(np.linspace(X['BATT_LEVEL'].min(), X['BATT_LEVEL'].max(), 500),
                     np.linspace(X['RANGE_EST'].min(), X['RANGE_EST'].max(), 500))

Z = isf.predict(np.c_[xx.ravel(), yy.ravel()])

Z = Z.reshape(xx.shape)
plt.figure(figsize=(15, 8))

plt.title('IsolationForest', size=18)

plt.scatter(X['BATT_LEVEL'], 
            X['RANGE_EST'], 
            s=100, 
            color=colors[(y_pred + 1) // 2])


plt.contour(xx, yy, Z, levels=[0], linewidths=2, colors='black')

plt.show()

from sklearn.neighbors import LocalOutlierFactor

lof = LocalOutlierFactor(n_neighbors=15, contamination='auto')

y_pred = lof.fit_predict(X)

y_pred


n_outliers = (y_pred == -1).sum()
n_outliers
plt.figure(figsize=(12, 10))

plt.title('Local Outlier Factor', size=18)

plt.scatter(X['BATT_LEVEL'], 
            X['RANGE_EST'], 
            s=100, 
            color=colors[(y_pred + 1) // 2])

plt.show()
X_scores = lof.negative_outlier_factor_
X_scores[0:10]

plt.figure(figsize=(15, 8))

radius = (X_scores.max() - X_scores) / (X_scores.max() - X_scores.min())

plt.scatter(X['BATT_LEVEL'], 
            X['RANGE_EST'], 
            s=1000 * radius, edgecolors='r',
            facecolors='none', 
            label='Outlier scores')

plt.show()
