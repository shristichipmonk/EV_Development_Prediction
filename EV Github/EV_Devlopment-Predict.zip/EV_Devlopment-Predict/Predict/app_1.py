from flask import Flask, render_template, request

app = Flask(__name__)

# Sample data
sample_data = [
    {'Date': '2023-01-01', 'Current_SOC': 80, 'Temperature': 25, 'Charge_Rate': 10, 'Distance_Traveled': 50},
    {'Date': '2023-01-02', 'Current_SOC': 75, 'Temperature': 28, 'Charge_Rate': 8, 'Distance_Traveled': 45},
    {'Date': '2023-01-03', 'Current_SOC': 70, 'Temperature': 23, 'Charge_Rate': 12, 'Distance_Traveled': 55},
    {'Date': '2023-01-04', 'Current_SOC': 65, 'Temperature': 20, 'Charge_Rate': 15, 'Distance_Traveled': 60},
    {'Date': '2023-01-05', 'Current_SOC': 60, 'Temperature': 22, 'Charge_Rate': 10, 'Distance_Traveled': 40},
    {'Date': '2023-01-06', 'Current_SOC': 55, 'Temperature': 25, 'Charge_Rate': 8, 'Distance_Traveled': 35},
    {'Date': '2023-01-07', 'Current_SOC': 50, 'Temperature': 30, 'Charge_Rate': 5, 'Distance_Traveled': 30},
    {'Date': '2023-01-08', 'Current_SOC': 45, 'Temperature': 28, 'Charge_Rate': 8, 'Distance_Traveled': 25},
    {'Date': '2023-01-09', 'Current_SOC': 40, 'Temperature': 22, 'Charge_Rate': 12, 'Distance_Traveled': 50},
    {'Date': '2023-01-10', 'Current_SOC': 35, 'Temperature': 25, 'Charge_Rate': 10, 'Distance_Traveled': 45},
]

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/predict_distance', methods=['POST'])
def predict_distance():
    soc_percentage = float(request.form['inputSOC'])
    future_date = request.form['inputFutureDate']

    # Find the closest SOC in the sample data
    closest_data = min(sample_data, key=lambda x: abs(x['Current_SOC'] - soc_percentage))

    # Use the found data for prediction
    current_soc = closest_data['Current_SOC']
    temperature = closest_data['Temperature']
    charge_rate = closest_data['Charge_Rate']

    # Perform a simple prediction (for demonstration purposes)
    # This is a basic linear model; you may want to use a more sophisticated model in a real-world scenario
    predicted_distance = current_soc * 0.5 + temperature * 0.2 + charge_rate * 0.3

    return render_template('index.html', soc_percentage=soc_percentage, future_date=future_date, predicted_distance=f'Predicted Distance: {predicted_distance:.2f} km')

if __name__ == '__main__':
    app.run(debug=True)


