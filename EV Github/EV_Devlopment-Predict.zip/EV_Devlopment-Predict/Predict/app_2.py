from flask import Flask, render_template, request
import csv

app = Flask(__name__)

# Function to load sample data from a CSV file
def load_sample_data():
    sample_data = []
    with open(r'C:\asbuilt\BMS_Predction\sample_data_2023.csv', 'r') as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            sample_data.append(row)
    return sample_data

# Load sample data from CSV file
sample_data = load_sample_data()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/predict_distance', methods=['POST'])
def predict_distance():
    soc_percentage = float(request.form['inputSOC'])
    future_date = request.form['inputFutureDate']

    # Find the closest SOC in the loaded sample data
    closest_data = min(sample_data, key=lambda x: abs(float(x['Current_SOC']) - soc_percentage))

    # Use the found data for prediction
    current_soc = float(closest_data['Current_SOC'])
    temperature = float(closest_data['Temperature'])
    charge_rate = float(closest_data['Charge_Rate'])

    # Perform a simple prediction (for demonstration purposes)
    # This is a basic linear model; you may want to use a more sophisticated model in a real-world scenario
    predicted_distance = current_soc * 0.5 + temperature * 0.2 + charge_rate * 0.3

    return render_template('index.html', soc_percentage=soc_percentage, future_date=future_date, predicted_distance=f'Predicted Distance: {predicted_distance:.2f} km')

if __name__ == '__main__':
    app.run(debug=True)
