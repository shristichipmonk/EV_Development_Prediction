import csv
import random
from datetime import datetime, timedelta

# Function to generate random date within a given range
def random_date(start_date, end_date):
    return start_date + timedelta(
        seconds=random.randint(0, int((end_date - start_date).total_seconds()))
    )

# Function to generate sample data for 2023
def generate_sample_data(start_date, end_date):
    current_date = start_date
    data = []

    while current_date <= end_date:
        data.append({
            'Date': current_date.strftime('%Y-%m-%d'),
            'Current_SOC': random.randint(20, 80),
            'Temperature': random.uniform(20, 30),
            'Charge_Rate': random.uniform(5, 15),
            'Distance_Traveled': random.uniform(20, 100)
        })
        current_date += timedelta(days=1)

    return data

# Set start and end date for 2023
start_date = datetime(2023, 1, 1)
end_date = datetime(2023, 12, 31)

# Generate sample data for 2023
sample_data = generate_sample_data(start_date, end_date)

# Save sample data to a CSV file
csv_file_path = 'sample_data_2023.csv'
fieldnames = ['Date', 'Current_SOC', 'Temperature', 'Charge_Rate', 'Distance_Traveled']

with open(csv_file_path, 'w', newline='') as csvfile:
    writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
    
    # Write the header
    writer.writeheader()

    # Write the data
    writer.writerows(sample_data)

print(f'Sample data for 2023 has been saved to {csv_file_path}')
