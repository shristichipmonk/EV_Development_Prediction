from flask import Flask, render_template, request
import csv
import pandas as pd
import matplotlib.pyplot as plt
from io import BytesIO
import base64
from statsmodels.tsa.arima.model import ARIMA

app = Flask(__name__)

# Function to load sample data from a CSV file
def load_sample_data():
    sample_data = []
    with open(r'C:\asbuilt\BMS_Predction\sample_data_2023.csv', 'r') as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            sample_data.append(row)
    return sample_data

# Load sample data from CSV file
sample_data = load_sample_data()

# Convert data to DataFrame
df = pd.DataFrame(sample_data)
df['Date'] = pd.to_datetime(df['Date'])
df['Distance_Traveled'] = pd.to_numeric(df['Distance_Traveled'], errors='coerce')  # Convert to numeric, handling errors
df.set_index('Date', inplace=True)
df.sort_index(inplace=True)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/predict_distance', methods=['POST'])
def predict_distance():
    soc_percentage = float(request.form['inputSOC'])
    future_date = pd.to_datetime(request.form['inputFutureDate'])

    # Find the closest SOC in the loaded sample data
    closest_data = min(df.iterrows(), key=lambda x: abs(float(x[1]['Current_SOC']) - soc_percentage))

    # Print data types to identify the issue
    print(df.dtypes)

    # Use the found data for prediction
    current_soc = float(closest_data[1]['Current_SOC'])
    temperature = float(closest_data[1]['Temperature'])
    charge_rate = float(closest_data[1]['Charge_Rate'])

    # Perform a simple prediction using ARIMA
    # You should fine-tune the model based on your actual data and requirements
    try:
        model = ARIMA(df['Distance_Traveled'].astype(float), order=(1, 1, 1))
        model_fit = model.fit()
        predicted_distance = model_fit.predict(start=len(df), end=len(df) + 5, typ='levels')
    except ValueError as e:
        print(f"Error: {e}")
        return render_template('index.html', error_message="Error in data type. Please check your data.")

    # Battery-related calculations
    battery_capacity = 100  # Assuming the battery capacity is 100 kWh
    remaining_capacity = battery_capacity - predicted_distance.iloc[-1]

    # Plotting
    plt.figure(figsize=(12, 6))
    plt.plot(df.index, df['Distance_Traveled'], label='Actual Distance')
    plt.plot(pd.date_range(start=df.index[-1], periods=6, freq='D'), predicted_distance, label='Predicted Distance', linestyle='--')
    plt.title('Battery Distance Traveled Over Time with Prediction')
    plt.xlabel('Date')
    plt.ylabel('Distance Traveled (km)')
    plt.legend()
    
    # Save the plot image
    plot_img_path = 'static/battery_analysis_plot.png'
    plt.savefig(plot_img_path)

    # Encoding the plot image to base64 for HTML display
    img_buf = BytesIO()
    plt.savefig(img_buf, format='png')
    img_buf.seek(0)
    plot_data = base64.b64encode(img_buf.read()).decode('utf-8')

    return render_template('index.html', soc_percentage=soc_percentage, future_date=future_date,
                           predicted_distance=f'Predicted Distance: {predicted_distance.iloc[-1]:.2f} km',
                           remaining_capacity=f'Remaining Capacity: {remaining_capacity:.2f} kWh',
                           plot_data=plot_data)

if __name__ == '__main__':
    app.run(debug=True)

