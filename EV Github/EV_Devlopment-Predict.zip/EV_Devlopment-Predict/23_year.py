import pandas as pd
import numpy as np
from datetime import datetime, timedelta

# Set the start and end date with hourly frequency
start_date = datetime(2000, 1, 1, 0, 0, 0)
end_date = datetime(2023, 1, 15, 23, 0, 0)

# Generate hourly date range
hourly_date_range = pd.date_range(start=start_date, end=end_date, freq='H')

# Generate synthetic distance data
np.random.seed(42)  # Set seed for reproducibility
distance_data = np.random.uniform(20, 100, size=len(hourly_date_range))

# Create a DataFrame
df = pd.DataFrame({'Date': hourly_date_range, 'Distance_Traveled': distance_data})

# Save the DataFrame to a CSV file
df.to_csv('sample_data_hourly_2000_to_2023.csv', index=False)

print("Hourly data generation and saving complete.")
