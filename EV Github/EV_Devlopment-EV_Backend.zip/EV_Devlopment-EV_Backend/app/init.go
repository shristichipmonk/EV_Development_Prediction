package app

import (
	"time"

	"github.com/Graylog2/go-gelf/gelf"
	"github.com/revel/revel"
)

var (
	// AppVersion revel app version (ldflags)
	AppVersion string

	// BuildTime revel app build-time (ldflags)
	BuildTime string
)

// HeaderFilter adds common security headers
var HeaderFilter = func(c *revel.Controller, fc []revel.Filter) {
	c.Response.Out.Header().Add("X-Frame-Options", "SAMEORIGIN")
	c.Response.Out.Header().Add("X-XSS-Protection", "1; mode=block")
	c.Response.Out.Header().Add("X-Content-Type-Options", "nosniff")
	c.Response.Out.Header().Add("Cache-Control", "no-cache, no-store, must-revalidate, max-stale=0, post-check=0, pre-check=0")
	fc[0](c, fc[1:]) // Execute the next filter stage.
	c.Response.Out.Header().Set("Access-Control-Allow-Origin", "*")
	c.Response.Out.Header().Set("Access-Control-Allow-Methods", "GET, POST, OPTIONS, PUT, DELETE")
	c.Response.Out.Header().Set("Access-Control-Allow-Headers", "*")

}

func init() {
	// Filters is the default set of global filters.
	revel.Filters = []revel.Filter{
		revel.PanicFilter,             // Recover from panics and display an error page instead.
		revel.RouterFilter,            // Use the routing table to select the right Action
		revel.FilterConfiguringFilter, // A hook for adding or removing per-Action filters.
		revel.ParamsFilter,            // Parse parameters into Controller.Params.
		revel.SessionFilter,           // Restore and write the session cookie.
		revel.FlashFilter,             // Restore and write the flash cookie.
		//csrf.CSRFFilter,               // CSRF prevention.
		revel.ValidationFilter,  // Restore kept validation errors and save new ones from cookie.
		revel.I18nFilter,        // Resolve the requested language
		HeaderFilter,            // Add some security based headers
		revel.InterceptorFilter, // Run interceptors around the action.
		revel.CompressFilter,    // Compress the result.
		revel.ActionInvoker,
		// Invoke the action.

	}

	// register startup functions with OnAppStart
	// revel.DevMode and revel.RunMode only work inside of OnAppStart. See Example Startup Script
	// ( order dependent )
	revel.OnAppStart(StartupScript)
	// revel.OnAppStart(FillCache)
}

func StartupScript() {
	//SetTimeFormat()
	//SetLogger()
}

func SetTimeFormat() {
	loc, _ := time.LoadLocation("Asia/Kolkata")
	time.Local = loc
}

func SetLogger() {
	logger := revel.Config.StringDefault("logger", "")
	if logger != "" {
		gelfWriter, err := gelf.NewWriter(logger)
		if err != nil {
			revel.INFO.Println(err)
		} else {
			revel.INFO.SetOutput(gelfWriter)
			revel.WARN.SetOutput(gelfWriter)
			revel.ERROR.SetOutput(gelfWriter)
		}
	}
}
