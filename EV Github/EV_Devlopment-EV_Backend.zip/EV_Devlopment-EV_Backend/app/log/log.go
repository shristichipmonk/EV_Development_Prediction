package log

import (
	//"bufio"
	"bytes"
	"encoding/binary"
	"encoding/json"
	"io"
	"log"
	"net/http"

	//	"os"
	"time"

	"github.com/boltdb/bolt"
	socketio "github.com/googollee/go-socket.io"
	"github.com/hpcloud/tail"
	"github.com/revel/revel"

	r "github.com/revel/revel"
)

const (
	maxbufflength = 5000
)

var (
	logger *log.Logger
	server *socketio.Server
	so     socketio.Socket
	buff   []string
	isconn bool
	db     = initLogDB()
)

type data struct {
	Time string
	Val  string
}

func initLogDB() *bolt.DB {
	db, err := bolt.Open("log.db", 0600, nil)
	if err != nil {
		//start the log server again
		r.ERROR.Println("ERROR IN OPENING log.db FILE. ERROR :", err)
		return nil
	}
	return db
}

func init() {
	// logger = log.New(os.Stdout, "runServer: ", log.Lshortfile)
	// go startLogServer()
}

func itob(v uint64) []byte {
	b := make([]byte, 8)
	binary.BigEndian.PutUint64(b, uint64(v))
	return b
}

func updateDB(t time.Time, ss string) {
	id := uint64(0)

	eorr := db.Update(func(tx *bolt.Tx) error {
		b := tx.Bucket([]byte("Log"))
		id, _ = b.NextSequence()

		da := data{t.Format(time.RFC3339), ss}
		buf, err := json.Marshal(da)
		if err != nil {
			return err
		}
		err = b.Put(itob((id)), buf)
		return err
	})
	if eorr != nil {
		logger.Println(eorr)
	}
	eorr = db.Update(func(tx *bolt.Tx) error {
		b := tx.Bucket([]byte("Ind"))
		err := b.Put([]byte(t.Format(time.RFC3339)), itob(id))
		return err
	})
	if eorr != nil {
		logger.Println(eorr)
	}
}

func GetRangeLogs(w http.ResponseWriter, r *http.Request) {
	from := r.URL.Query().Get("from")
	to := r.URL.Query().Get("to")

	loc, _ := time.LoadLocation("Asia/Kolkata")
	tf, _ := time.ParseInLocation("01/02/2006 3:04 PM", from, loc)
	tt, _ := time.ParseInLocation("01/02/2006 3:04 PM", to, loc)

	restr := ""
	db.View(func(tx *bolt.Tx) error {
		// Assume our events bucket exists and has RFC3339 encoded time keys.
		c := tx.Bucket([]byte("Ind")).Cursor()
		min := tf.Format(time.RFC3339)
		max := tt.Format(time.RFC3339)
		log.Println("From=", min, " To=", max)

		_, mi := c.Seek([]byte(min))
		_, ma := c.Seek([]byte(max))
		if ma == nil {
			_, ma = c.Last()
		}

		// retrieve all logs in given range
		c = tx.Bucket([]byte("Log")).Cursor()
		x := 0
		for k, v := c.Seek(mi); k != nil && bytes.Compare(k, ma) <= 0; k, v = c.Next() {
			//log.Println(string(v))
			if x != 0 {
				restr += "##"
			}
			da := data{}
			err := json.Unmarshal(v, &da)
			if err != nil {
				logger.Println(err)
				continue
			}
			t, _ := time.ParseInLocation(time.RFC3339, da.Time, loc)
			ss := t.Format(time.RFC850)
			ss += "=>" + da.Val
			restr += ss
			x++
		}
		logger.Println("x ", x)
		return nil
	})
	io.WriteString(w, restr)
}

func processLog() {
	loc, _ := time.LoadLocation("Asia/Kolkata")

	t, err := tail.TailFile("EV.log", tail.Config{Follow: true, ReOpen: true})
	if err != nil {
		revel.WARN.Println("ERROR IN OPENING LOG FILE")
		return
	}

	for line := range t.Lines {
		log.Println(line.Text)

		t, _ := time.ParseInLocation("01/02/2006 3:04:05 PM",
			time.Now().In(loc).Format("01/02/2006 3:04:05 PM"), loc)
		ss := line.Text
		go updateDB(t, ss)
		str := t.Format(time.RFC850) + "=>"
		str += ss

		if len(buff) > maxbufflength {
			buff = buff[1:]
		}
		buff = append(buff, str)

		if isconn {
			so.Emit("chat message", str)
			so.BroadcastTo("chat", "chat message", str)
		}
	}
}

func startLogServer() {

	defer db.Close()

	maidd := uint64(0)
	//Create log and time bucket
	eorr := db.Update(func(tx *bolt.Tx) error {
		_, err := tx.CreateBucketIfNotExists([]byte("Log"))
		if err != nil {
			logger.Println("create bucket: ", err)
			return err
		}
		_, err = tx.CreateBucketIfNotExists([]byte("Ind"))
		if err != nil {
			logger.Println("create bucket: ", err)
			return err
		}
		return nil
	})
	if eorr != nil {
		logger.Println(eorr)
	}

	server, err := socketio.NewServer(nil)
	if err != nil {
		log.Fatal(err)
	}

	loc, _ := time.LoadLocation("Asia/Kolkata")

	server.On("connection", func(so1 socketio.Socket) {
		so = so1
		so.Join("chat")
		isconn = true
		log.Println("on connection")
		restr := ""
		db.View(func(tx *bolt.Tx) error {
			// Assume our events bucket exists and has RFC3339 encoded time keys.
			c := tx.Bucket([]byte("Log")).Cursor()
			maid, _ := c.Last()
			if len(maid) != 0 {
				maidd = binary.BigEndian.Uint64(maid)
			} else {
				maidd = uint64(0)
			}
			id := (maidd)
			logger.Println("max=", id)
			min := uint64(0)
			if id > 20 {
				min = id - 20
			}
			max := id
			x := 0
			for k, v := c.Seek(itob(min)); k != nil && bytes.Compare(k, itob(max)) <= 0; k, v = c.Next() {
				if x != 0 {
					restr += "##"
				}
				da := data{}
				err := json.Unmarshal(v, &da)
				if err != nil {
					logger.Println(err)
				}
				t, _ := time.ParseInLocation(time.RFC3339, da.Time, loc)
				ss := t.Format(time.RFC850)
				ss += "=>" + da.Val
				restr += ss
				x++
			}
			return nil
		})
		if restr != "" {
			so.Emit("chat message", restr)
		}
	})
	server.On("error", func(so socketio.Socket, err error) {
		log.Println("error:", err)
	})

	go processLog()
	http.Handle("/socket.io/", server)
	http.Handle("/", http.FileServer(http.Dir("./public/assets/log")))
	http.HandleFunc("/logs/range/", GetRangeLogs)

	log.Println("Serving at localhost:9002...")
	log.Fatal(http.ListenAndServe(":9008", nil))
}
