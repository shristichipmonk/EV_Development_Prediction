package controllers

import (
	"database/sql"
	"log"
	"net/http"

	m "github.com/EV_Devlopment/app/models"
	r "github.com/revel/revel"
)

type App struct {
	GorpController
}

type First struct {
	App
}

type HistoricalReq struct {
	VehicleId string `json:"vehicle_id"`
	StartTime string `json:"start_time"`
	EndTime   string `json:"end_time"`
}

func enableCors(w *http.ResponseWriter) {
	(*w).Header().Set("Access-Control-Allow-Origin", "*")
}

func (t *First) GetBatteryInfo(vin string) r.Result {
	log.Println("Inside the GetBatteryInfo", vin)
	queryStr := "SELECT * FROM batterypack where vehicleid = '" + vin + "'"

	var batterypackinfo m.BatteryPack
	err1 := m.Dbm.SelectOne(&batterypackinfo, queryStr)
	if err1 == sql.ErrNoRows {
		r.ERROR.Println("id does not exist: ", vin)

		t.Response.Status = 500
		return t.RenderJSON("does not exist ok: " + vin)
	} else if err1 != nil {
		r.ERROR.Println("Unable to query id from DB. Error is: ", err1)

		t.Response.Status = 500

		return t.RenderJSON("Error in querying DB ")
	}

	return t.RenderJSON(batterypackinfo)
}

func (t *First) GetTelemetryInfo(vin string) r.Result {
	log.Println("Inside the GetTelemetryInfo", vin)

	queryStr, err := m.Dbm.SelectStr("SELECT batteryid FROM batterypack where vehicleid = $1", vin)
	log.Println("Battery Id:", queryStr)
	if err == sql.ErrNoRows {
		r.ERROR.Println("Vehicle does not have battery: ", vin)
		t.Response.Status = 500
		return t.RenderJSON("Vehicle does not have battery: " + vin)
	} else if err != nil {
		r.ERROR.Println("Unable to query id from DB. Error is: ", err)
		t.Response.Status = 500
		return t.RenderJSON("Error in querying DB ")
	}
	var batterycell m.BatteryCell
	queryStr1 := "SELECT * FROM batterycell where batteryid = '" + queryStr + "'"

	err1 := m.Dbm.SelectOne(&batterycell, queryStr1)
	if err1 == sql.ErrNoRows {
		r.ERROR.Println("id does not exist: ", queryStr)

		t.Response.Status = 500
		return t.RenderJSON("does not exist: " + queryStr)
	} else if err1 != nil {
		r.ERROR.Println("Unable to query id from DB. Error is: ", err1)

		t.Response.Status = 500

		return t.RenderJSON("Error in querying DB ")
	}

	return t.RenderJSON(batterycell)
}

func (t *First) GetChargingInfo(vin string) r.Result {
	log.Println("Inside the GetChargingInfo", vin)

	queryStr, err := m.Dbm.SelectStr("SELECT batteryid FROM batterypack where vehicleid = $1", vin)
	log.Println("Battery Id:", queryStr)
	if err == sql.ErrNoRows {
		r.ERROR.Println("Vehicle does not have battery: ", vin)
		t.Response.Status = 500
		return t.RenderJSON("Vehicle does not have battery: " + vin)
	} else if err != nil {
		r.ERROR.Println("Unable to query id from DB. Error is: ", err)
		t.Response.Status = 500
		return t.RenderJSON("Error in querying DB ")
	}
	var chargedischargehistory m.ChargeDischargeHistory
	queryStr1 := "SELECT * FROM chargedischargehistory where batteryid = '" + queryStr + "'"

	err1 := m.Dbm.SelectOne(&chargedischargehistory, queryStr1)
	if err1 == sql.ErrNoRows {
		r.ERROR.Println("id does not exist: ", queryStr)

		t.Response.Status = 500
		return t.RenderJSON("does not exist: " + queryStr)
	} else if err1 != nil {
		r.ERROR.Println("Unable to query id from DB. Error is: ", err1)

		t.Response.Status = 500

		return t.RenderJSON("Error in querying DB ")
	}

	return t.RenderJSON(chargedischargehistory)
}

func (t *First) BatteryAlerts(vin string) r.Result {
	log.Println("Inside the GetDiagnosticsInfo", vin)

	queryStr, err := m.Dbm.SelectStr("SELECT batteryid FROM batterypack where vehicleid = $1", vin)
	log.Println("Battery Id:", queryStr)
	if err == sql.ErrNoRows {
		r.ERROR.Println("Vehicle does not have battery: ", vin)
		t.Response.Status = 500
		return t.RenderJSON("Vehicle does not have battery: " + vin)
	} else if err != nil {
		r.ERROR.Println("Unable to query id from DB. Error is: ", err)
		t.Response.Status = 500
		return t.RenderJSON("Error in querying DB ")
	}
	var alarmhistory m.AlarmHistory
	queryStr1 := "SELECT * FROM alarmhistory where batteryid = '" + queryStr + "'"

	err1 := m.Dbm.SelectOne(&alarmhistory, queryStr1)
	if err1 == sql.ErrNoRows {
		r.ERROR.Println("id does not exist: ", queryStr)

		t.Response.Status = 500
		return t.RenderJSON("does not exist: " + queryStr)
	} else if err1 != nil {
		r.ERROR.Println("Unable to query id from DB. Error is: ", err1)

		t.Response.Status = 500

		return t.RenderJSON("Error in querying DB ")
	}

	return t.RenderJSON(alarmhistory)
}

func (t *First) VehicleInfo(vin string) r.Result {
	log.Println("Inside the GetBatteryInfo", vin)
	queryStr := "SELECT * FROM vehicle_master where vehivle_id = '" + vin + "'"

	var vehiclemaster m.Vehicle_Master
	err1 := m.Dbm.SelectOne(&vehiclemaster, queryStr)
	if err1 == sql.ErrNoRows {
		r.ERROR.Println("id does not exist: ", vin)

		t.Response.Status = 500
		return t.RenderJSON("does not exist ok: " + vin)
	} else if err1 != nil {
		r.ERROR.Println("Unable to query id from DB. Error is: ", err1)

		t.Response.Status = 500

		return t.RenderJSON("Error in querying DB ")
	}

	return t.RenderJSON(vehiclemaster)
}

func (t *First) ChargingRecommendation(vin string) r.Result {
	log.Println("Inside the GetChargingInfo", vin)

	queryStr, err := m.Dbm.SelectStr("SELECT batteryid FROM batterypack where vehicleid = $1", vin)
	log.Println("Battery Id:", queryStr)
	if err == sql.ErrNoRows {
		r.ERROR.Println("Vehicle does not have battery: ", vin)
		t.Response.Status = 500
		return t.RenderJSON("Vehicle does not have battery: " + vin)
	} else if err != nil {
		r.ERROR.Println("Unable to query id from DB. Error is: ", err)
		t.Response.Status = 500
		return t.RenderJSON("Error in querying DB ")
	}
	var chargedischargehistory m.ChargeDischargeHistory
	queryStr1 := "SELECT * FROM chargedischargehistory where batteryid = '" + queryStr + "'"

	err1 := m.Dbm.SelectOne(&chargedischargehistory, queryStr1)
	if err1 == sql.ErrNoRows {
		r.ERROR.Println("id does not exist: ", queryStr)

		t.Response.Status = 500
		return t.RenderJSON("does not exist: " + queryStr)
	} else if err1 != nil {
		r.ERROR.Println("Unable to query id from DB. Error is: ", err1)

		t.Response.Status = 500

		return t.RenderJSON("Error in querying DB ")
	}

	return t.RenderJSON(chargedischargehistory)
}

func (t *First) Mastervhicleinfo(vin string) r.Result {
	log.Println("Inside the Mastervhicleinfo", vin)

	var vehicle m.Vehicle
	queryStr1 := "SELECT * FROM vehicle where vehivle_id = '" + vin + "'"

	err1 := m.Dbm.SelectOne(&vehicle, queryStr1)
	if err1 == sql.ErrNoRows {
		r.ERROR.Println("id does not exist: ", vin)

		t.Response.Status = 500
		return t.RenderJSON("does not exist: " + vin)
	} else if err1 != nil {
		r.ERROR.Println("Unable to query id from DB. Error is: ", err1)

		t.Response.Status = 500

		return t.RenderJSON("Error in querying DB ")
	}

	return t.RenderJSON(vehicle)
}

func (t *First) AllVhicleinfo() r.Result {
	log.Println("Inside the AllVhicleinfo")

	vehicle := []m.AllVehicle{}
	if _, errSelect := m.Dbm.Select(&vehicle, "SELECT  *  FROM vehicle "); errSelect != nil {
		log.Println("Error in Query:", errSelect)
	} else {
		log.Println("listOfvehicle: ", vehicle)
	}
	log.Println("Vehicledata: ", vehicle)
	return t.RenderJSON(vehicle)
}

func (t *First) VehicleHealth(vin string) r.Result {
	log.Println("Inside the VehicleHealth", vin)
	vehiclehealth := []m.VehicleHealth{}
	if vin == "All" {
		if _, errSelect := m.Dbm.Select(&vehiclehealth, "SELECT * FROM vehiclehealth"); errSelect != nil {
			log.Println("Error in Query:", errSelect)
		} else {
			log.Println("-----vehiclehealth: -----", vehiclehealth)
		}
	} else {
		if _, errSelect := m.Dbm.Select(&vehiclehealth, "SELECT * FROM vehiclehealth where vehicleid ='"+vin+"'"); errSelect != nil {
			log.Println("Error in Query:", errSelect)
		} else {
			log.Println("-----vehiclehealth: -----", vehiclehealth)
		}
	}
	return t.RenderJSON(vehiclehealth)
}

func (t *First) Alarmsdetails(vin string) r.Result {

	var vehicle_alarms m.Vehicle
	queryStr := "select * from vehicle where vehivle_id= '" + vin + "'"
	err := m.Dbm.SelectOne(&vehicle_alarms, queryStr)
	if err == sql.ErrNoRows {
		r.ERROR.Println("id does not exist", vin)
		t.Response.Status = 500
		return t.RenderJSON("does not exist: " + vin)
	} else if err != nil {
		r.ERROR.Println("Unable to query id from DB. Error is: ", err)
		t.Response.Status = 500
		return t.RenderJSON("Error in quering DB")
	}

	if vehicle_alarms.RemainingRange < 10 {
		return t.RenderJSON("Remining range is less than 10km")
	} else if vehicle_alarms.Speed > 90 {
		return t.RenderJSON("Speed is more than 90kmph.")
	} else if vehicle_alarms.StabilityControlStatus == "Off" {
		return t.RenderJSON("Stability control status is Off.")
	} else if vehicle_alarms.AbsStatus == "Off" {
		return t.RenderJSON("Abs Status is Off.")
	} else if vehicle_alarms.Odometer > 12000 {
		return t.RenderJSON("Odometer is high than usual.")
	}

	return t.RenderJSON(nil)

}

/////////////////////////
func (t *First) DashboardInfo() r.Result {
	log.Println("Inside the DashboardInfo")
	VehicleData := []m.VehicleData{}
	if _, errSelect := m.Dbm.Select(&VehicleData, "SELECT v.vehivle_id, vm.make, vm.model, v.state_of_charge,v.battery_voltage, v.battery_current, vh.tirepressurefront_l, vh.tirepressurefront_r, vh.tirepressurerear_r, vh.tirepressurerear_l, vh.wheelalignment, vh.motorhealth, vh.inverterhealth, v.interior_temperature FROM vehicle_master vm JOIN vehicle v ON vm.vehivle_id = v.vehivle_id JOIN vehiclehealth vh ON vm.vehivle_id = vh.vehicleid"); errSelect != nil {
		log.Println("Error in Query:", errSelect)
	} else {
		log.Println("-----vehiclehealth: -----", VehicleData)
	}
	//queryStr1 := "SELECT vm.vehivle_id, vm.make, vm.model, v.state_of_charge,v.battery_voltage, v.battery_current, vh.tirepressurefront_l, vh.tirepressurefront_r, vh.tirepressurerear_r, vh.tirepressurerear_l, vh.wheelalignment, vh.motorhealth, vh.inverterhealth, v.interior_temperature FROM vehicle_master vm JOIN vehicle v ON vm.vehivle_id = v.vehivle_id JOIN vehiclehealth vh ON vm.vehivle_id = vh.vehicleid "

	return t.RenderJSON(VehicleData)
}

func (t *First) DistanceInfo(id string) r.Result {
	log.Println("Inside the GetBatteryInfo", id)
	queryStr := "SELECT distance_to_vehicle FROM chargingstation where vehicle_id = '" + id + "' AND distance_to_vehicle IS NOT NULL LIMIT 1;"

	var chargingstation m.NearChargingStation
	err1 := m.Dbm.SelectOne(&chargingstation, queryStr)
	if err1 == sql.ErrNoRows {
		r.ERROR.Println("id does not exist: ", id)

		t.Response.Status = 500
		return t.RenderJSON("does not exist ok: " + id)
	} else if err1 != nil {
		r.ERROR.Println("Unable to query id from DB. Error is: ", err1)

		t.Response.Status = 500

		return t.RenderJSON("Error in querying DB")
	}
	return t.RenderJSON(chargingstation.Distance_To_Vehicle)
}

func (t *First) ChargingStation(vin string) r.Result {
	log.Println("Inside the Charging Station", vin)
	chargingstation := []m.ChargingStationLoc{}
	if vin == "All" {
		if _, errSelect := m.Dbm.Select(&chargingstation, "SELECT * FROM chargingstation"); errSelect != nil {
			log.Println("Error in Query:", errSelect)
		} else {
			log.Println("-----Charging Station: -----", chargingstation)
		}
	} else {
		if _, errSelect := m.Dbm.Select(&chargingstation, "SELECT * FROM chargingstation where vehicle_id ='"+vin+"'"); errSelect != nil {
			log.Println("Error in Query:", errSelect)
		} else {
			log.Println("-----Charging Station -----", chargingstation)
		}
	}
	return t.RenderJSON(chargingstation)
}

func (t *First) HistoricalData(vin, stime, etime, para string) r.Result {
	log.Println("Inside Historical data", vin, stime, etime, para)
	// var req HistoricalReq
	// if err := json.Unmarshal(t.Params.JSON, &req); err != nil {
	// 	log.Println("Error binding params: ", err)
	// 	t.Response.Status = 400
	// 	log.Println("JSON Values :", req)

	// 	return t.RenderJSON("Invalid Request")
	// }
	// log.Println("Historical data request:", req)
	HistoricalData := []m.HistoricalData{}
	HistoricalDataVol := []m.HistoricalDataVol{}
	HistoricalDataSOC := []m.HistoricalDataSOC{}
	HistoricalDataER := []m.HistoricalDataER{}
	HistoricalDataRR := []m.HistoricalDataRR{}
	HistoricalDataTemp := []m.HistoricalDataTemp{}
	HistoricalDataLoc := []m.HistoricalDataLoc{}
	HistoricalDataSpeed := []m.HistoricalDataSpeed{}
	HistoricalDataCurr := []m.HistoricalDataCurr{}

	if para == " " {
		log.Println("Parameter is not valid")
		return t.RenderJSON("No Parameter selected Available")

	}
	if para == "all" {
		if _, err := m.Dbm.Select(&HistoricalData, "SELECT * from historicaldata WHERE vehicle_id= $1 and updated_time between  $2 and $3 ", vin, stime, etime); err != nil {
			log.Println("Error while fetching historicaldata from DB: ", err)
		} else {
			log.Println("-----HistoricalData: -----", HistoricalData)
		}
		if len(HistoricalData) == 0 {
			log.Println("No data available")
			return t.RenderJSON("No History Data Available")
		}
	} else if para == "Voltage" {
		if _, err := m.Dbm.Select(&HistoricalDataVol, "SELECT vehicle_id, battery_id, voltage, updated_time from historicaldata WHERE vehicle_id= $1 and updated_time between  $2 and $3 ", vin, stime, etime); err != nil {
			log.Println("Error while fetching historicaldata from DB: ", err)
		} else {
			log.Println("-----HistoricalData: -----", HistoricalDataVol)
		}
		if len(HistoricalDataVol) == 0 {
			log.Println("No data available")
			return t.RenderJSON("No History Data Available")
		}
		return t.RenderJSON(HistoricalDataVol)
	} else if para == "State_Of_Charge" {
		if _, err := m.Dbm.Select(&HistoricalDataSOC, "SELECT vehicle_id, battery_id, state_of_charge, updated_time from historicaldata WHERE vehicle_id= $1 and updated_time between  $2 and $3 ", vin, stime, etime); err != nil {
			log.Println("Error while fetching historicaldata from DB: ", err)
		} else {
			log.Println("-----HistoricalData: -----", HistoricalDataSOC)
		}
		if len(HistoricalDataSOC) == 0 {
			log.Println("No data available")
			return t.RenderJSON("No History Data Available")
		}
		return t.RenderJSON(HistoricalDataSOC)
	} else if para == "EstimatedRange" {
		if _, err := m.Dbm.Select(&HistoricalDataER, "SELECT vehicle_id, battery_id, estimatedrange, updated_time from historicaldata WHERE vehicle_id= $1 and updated_time between  $2 and $3 ", vin, stime, etime); err != nil {
			log.Println("Error while fetching historicaldata from DB: ", err)
		} else {
			log.Println("-----HistoricalData: -----", HistoricalDataER)
		}
		if len(HistoricalDataER) == 0 {
			log.Println("No data available")
			return t.RenderJSON("No History Data Available")
		}
		return t.RenderJSON(HistoricalDataER)
	} else if para == "RemainingRange" {
		if _, err := m.Dbm.Select(&HistoricalDataRR, "SELECT vehicle_id, battery_id, remaining_range, updated_time from historicaldata WHERE vehicle_id= $1 and updated_time between  $2 and $3 ", vin, stime, etime); err != nil {
			log.Println("Error while fetching historicaldata from DB: ", err)
		} else {
			log.Println("-----HistoricalData: -----", HistoricalDataRR)
		}
		if len(HistoricalDataRR) == 0 {
			log.Println("No data available")
			return t.RenderJSON("No History Data Available")
		}
		return t.RenderJSON(HistoricalDataRR)
	} else if para == "InteriorTemperature" {
		if _, err := m.Dbm.Select(&HistoricalDataTemp, "SELECT vehicle_id, battery_id, interior_temperature, updated_time from historicaldata WHERE vehicle_id= $1 and updated_time between  $2 and $3 ", vin, stime, etime); err != nil {
			log.Println("Error while fetching historicaldata from DB: ", err)
		} else {
			log.Println("-----HistoricalData: -----", HistoricalDataTemp)
		}
		if len(HistoricalDataTemp) == 0 {
			log.Println("No data available")
			return t.RenderJSON("No History Data Available")
		}
		return t.RenderJSON(HistoricalDataTemp)
	} else if para == "Latitude_Longitude" {
		if _, err := m.Dbm.Select(&HistoricalDataLoc, "SELECT vehicle_id, battery_id, latitude, longitude, updated_time from historicaldata WHERE vehicle_id= $1 and updated_time between  $2 and $3 ", vin, stime, etime); err != nil {
			log.Println("Error while fetching historicaldata from DB: ", err)
		} else {
			log.Println("-----HistoricalData: -----", HistoricalDataLoc)
		}
		if len(HistoricalDataLoc) == 0 {
			log.Println("No data available")
			return t.RenderJSON("No History Data Available")
		}
		return t.RenderJSON(HistoricalDataLoc)
	} else if para == "Speed" {
		if _, err := m.Dbm.Select(&HistoricalDataSpeed, "SELECT vehicle_id, battery_id, speed, updated_time from historicaldata WHERE vehicle_id= $1 and updated_time between  $2 and $3 ", vin, stime, etime); err != nil {
			log.Println("Error while fetching historicaldata from DB: ", err)
		} else {
			log.Println("-----HistoricalData: -----", HistoricalDataSpeed)
		}
		if len(HistoricalDataSpeed) == 0 {
			log.Println("No data available")
			return t.RenderJSON("No History Data Available")
		}
		return t.RenderJSON(HistoricalDataSpeed)
	} else if para == "Current" {
		if _, err := m.Dbm.Select(&HistoricalDataCurr, "SELECT vehicle_id, battery_id, current, updated_time from historicaldata WHERE vehicle_id= $1 and updated_time between  $2 and $3 ", vin, stime, etime); err != nil {
			log.Println("Error while fetching historicaldata from DB: ", err)
		} else {
			log.Println("-----HistoricalData: -----", HistoricalDataCurr)
		}
		if len(HistoricalDataCurr) == 0 {
			log.Println("No data available")
			return t.RenderJSON("No History Data Available")
		}
		return t.RenderJSON(HistoricalDataCurr)
	} else {
		log.Println("Select Valied Parameter")
		return t.RenderJSON("Parameter is not valid")

	}
	return t.RenderJSON(HistoricalData)

}
