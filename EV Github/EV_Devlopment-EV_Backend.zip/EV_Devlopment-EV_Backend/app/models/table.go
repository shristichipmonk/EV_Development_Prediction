package models

import (
	"time"
)

type BatteryPack struct {
	BatteryPackID string  `db:"batteryid,primarykey"`
	VehicleID     string  `db:"vehicleid"`
	Manufacturer  string  `db:"manufacturer"`
	Model         string  `db:"model"`
	Capacity      float64 `db:"capacity"`
}

type BatteryCell struct {
	CellID             string  `db:"cellid,primarykey"`
	BatteryPackID      string  `db:"batteryid"`
	Voltage            float64 `db:"voltage"`
	Temperature        float64 `db:"temperature"`
	StateOfCharge      float64 `db:"state_of_charge"`
	StateOfHealth      float64 `db:"state_of_health"`
	InternalResistance float64 `db:"internal_resistance"`
}

type ChargeDischargeHistory struct {
	HistoryID        string    `db:"historyid,primarykey"`
	BatteryPackID    string    `db:"batteryid"`
	DateTime         time.Time `db:"datetime"`
	ChargeRate       float64   `db:"chargerate"`
	DischargeRate    float64   `db:"dischargerate"`
	ChargeEfficiency float64   `db:"chargeefficiency"`
}

type CycleHistory struct {
	CycleID        string `db:"cycleid,primarykey"`
	BatteryPackID  string `db:"batteryid"`
	NumberOfCycles int64  `db:"number_of_cycles"`
}

type AlarmHistory struct {
	AlarmID       string    `db:"alarmid,primarykey"`
	BatteryPackID string    `db:"batteryid"`
	DateTime      time.Time `db:"datetime"`
	AlarmType     string    `db:"alarmtype"`
	Description   string    `db:"description"`
}

type CellBalancing struct {
	BalancingID     string    `db:"balancingid,primarykey"`
	BatteryPackID   string    `db:"batteryid"`
	DateTime        time.Time `db:"datetime"`
	BalancingStatus string    `db:"balancingstatus"`
}

type AmbientTemperature struct {
	TemperatureID      string    `db:"temperatureid,primarykey"`
	BatteryPackID      string    `db:"batteryid"`
	DateTime           time.Time `db:"datetime"`
	AmbientTemperature float64   `db:"ambientTemperature"`
}

type RegenerativeBrakingTable struct {
	RecordID             string    `db:"recordid,primarykey"`
	BatteryPackID        string    `db:"batteryid"`
	Timestamp            time.Time `db:"timestamp"`
	RegenerativeCurrent  float64   `db:"regeneratecurrent"`
	RegenerativePower    float64   `db:"regenerativepower"`
	SOCAdjustment        float64   `db:"socadjustment"`
	Temperature          float64   `db:"temperature"`
	CellVoltageBalancing float64   `db:"cellvoltagebalancing"`
	ChargeEfficiency     float64   `db:"chargeefficiency"`
}

type Vehicle struct {
	VehicleId               string    `db:"vehivle_id,primarykey"`
	VehicleName             string    `db:"vehicle_name"`
	ManufactureYear         int       `db:"manufacture_year"`
	Model                   string    `db:"model"`
	Batterycapacity         int       `db:"battery_capacity"`
	Batteryvoltage          float64   `db:"battery_voltage"`
	Batterycurrent          float64   `db:"battery_current"`
	StateOfCharge           int       `db:"state_of_charge"`
	ChargingStatus          string    `db:"charging_status"`
	EstimatedRange          int       `db:"estimated_range"`
	RemainingRange          int       `db:"remaining_range"`
	Motortype               string    `db:"motor_type"`
	MotorPower              int       `db:"motor_power"`
	Motortorque             int       `db:"motor_torque"`
	InteriorTemperature     float64   `db:"interior_temperature"`
	ExteriorTemperature     float64   `db:"exterior_temperature"`
	LastKnownLatitude       float64   `db:"last_known_latitude"`
	LastKnownLongitude      float64   `db:"last_known_longitude"`
	LastKnownTimestamp      time.Time `db:"last_known_timestamp"`
	AirbagStatus            string    `db:"airbag_status"`
	AbsStatus               string    `db:"abs_status"`
	TractionControlStatus   string    `db:"traction_control_status"`
	StabilityControlStatus  string    `db:"stability_control_status"`
	Speed                   int       `db:"speed"`
	Acceleration            int       `db:"acceleration"`
	Odometer                int       `db:"odometer"`
	InformationSystemStatus string    `db:"information_system_status"`
	WiperStatus             string    `db:"wiper_status"`
	HornStatus              string    `db:"horn_status"`
	LightingSystemStatus    string    `db:"lighting_system_status"`
	LastUpdateTime          time.Time `db:"last_update_time"`
}

type AllVehicle struct {
	VehicleId               string    `db:"vehivle_id,primarykey"`
	VehicleName             string    `db:"vehicle_name"`
	ManufactureYear         int       `db:"manufacture_year"`
	Model                   string    `db:"model"`
	Batterycapacity         int       `db:"battery_capacity"`
	Batteryvoltage          float64   `db:"battery_voltage"`
	Batterycurrent          float64   `db:"battery_current"`
	StateOfCharge           int       `db:"state_of_charge"`
	ChargingStatus          string    `db:"charging_status"`
	EstimatedRange          int       `db:"estimated_range"`
	RemainingRange          int       `db:"remaining_range"`
	Motortype               string    `db:"motor_type"`
	MotorPower              int       `db:"motor_power"`
	Motortorque             int       `db:"motor_torque"`
	InteriorTemperature     float64   `db:"interior_temperature"`
	ExteriorTemperature     float64   `db:"exterior_temperature"`
	LastKnownLatitude       float64   `db:"last_known_latitude"`
	LastKnownLongitude      float64   `db:"last_known_longitude"`
	LastKnownTimestamp      time.Time `db:"last_known_timestamp"`
	AirbagStatus            string    `db:"airbag_status"`
	AbsStatus               string    `db:"abs_status"`
	TractionControlStatus   string    `db:"traction_control_status"`
	StabilityControlStatus  string    `db:"stability_control_status"`
	Speed                   int       `db:"speed"`
	Acceleration            int       `db:"acceleration"`
	Odometer                int       `db:"odometer"`
	InformationSystemStatus string    `db:"information_system_status"`
	WiperStatus             string    `db:"wiper_status"`
	HornStatus              string    `db:"horn_status"`
	LightingSystemStatus    string    `db:"lighting_system_status"`
	LastUpdateTime          time.Time `db:"last_update_time"`
}

type Vehicle_Master struct {
	VehicleId     string  `db:"vehivle_id,primarykey"`
	Make          string  `db:"make"`
	Model         string  `db:"model"`
	Year          string  `db:"year"`
	BatteryPackID string  `db:"batterypackid"`
	Latitude      float64 `db:"latitude"`
	Longitude     float64 `db:"longitude"`
}

type BatteryPack_Master struct {
	BatteryPackID string  `db:"batteryid,primarykey"`
	Manufacturer  string  `db:"manufacturer"`
	Model         string  `db:"model"`
	Capacity      float64 `db:"capacity"`
}

type ChargingHistory struct {
	ChargingID   int     `db:"chargingid,primarykey"`
	VehicleID    int     `db:"vehicleid"`
	DateTime     string  `db:"datetime"`
	ChargingRate float64 `db:"chargingrate"`
	ChargeLevel  float64 `db:"chargelevel"`
}

type RangePrediction struct {
	PredictionID   int     `db:"predictionid,primarykey"`
	VehicleID      int     `db:"vehicleid"`
	DateTime       string  `db:"datetime"`
	PredictedRange float64 `db:"predictedrange"`
}

type ChargingStation struct {
	Id                  int     `db:"id,primarykey"`
	Name                string  `db:"string"`
	Latitude            float64 `db:"latitude"`
	Longitude           float64 `db:"longitude"`
	Power_Available     float64 `db:"power_available"`
	Distance_To_Vehicle float64 `db:"distance_to_vehicle"`
	VehicleID           string  `db:"vehicle_id"`
	Num_Docks           float64 `db:"num_docks"`
}

type ChargingStationLoc struct {
	Id              int     `db:"id,primarykey"`
	Name            string  `db:"string"`
	Latitude        float64 `db:"latitude"`
	Longitude       float64 `db:"longitude"`
	Power_Available float64 `db:"power_available"`
	Num_Docks       float64 `db:"num_docks"`
}
type NearChargingStation struct {
	Name                string  `db:"string"`
	Distance_To_Vehicle float64 `db:"distance_to_vehicle"`
}

type VehicleHealth struct {
	VehicleId           string    `db:"vehicleid,primarykey"`
	Timestamp           time.Time `db:"timestamp"`
	TirePressureFrontL  int       `db:"tirepressurefront_l"`
	TirePressureFrontR  int       `db:"tirepressurefront_r"`
	TirePressureRearR   int       `db:"tirepressurerear_r"`
	TirePressureRearL   int       `db:"tirepressurerear_l"`
	BrakeHealth         string    `db:"brakehealth"`
	Suspension          string    `db:"suspension"`
	SteeringAlignment   string    `db:"steeringalignment"`
	FluidLevel          string    `db:"fluidlevel"`
	AirFilter           string    `db:"airfilter"`
	MotorHealth         string    `db:"motorhealth"`
	InverterHealth      string    `db:"inverterhealth"`
	RegenerativeBraking string    `db:"regenerativebraking"`
	WheelAlignment      string    `db:"wheelalignment"`
	PowerSteering       string    `db:"powersteering"`
	NormsId             string    `db:"normsid"`
}

// type DashboardInfo struct {
// 	VehicleId           string  `json:"vehivle_id"`
// 	Model               string  `json:"model"`
// 	Make                string  `json:"make"`
// 	StateOfCharge       int     `json:"state_of_charge"`
// 	Batteryvoltage      float64 `json:"battery_voltage"`
// 	Batterycurrent      float64 `json:"battery_current"`
// 	TirePressureFrontL  int     `json:"tirepressurefront_l"`
// 	TirePressureFrontR  int     `json:"tirepressurefront_r"`
// 	TirePressureRearR   int     `json:"tirepressurerear_r"`
// 	TirePressureRearL   int     `json:"tirepressurerear_l"`
// 	SteeringAlignment   string  `json:"steeringalignment"`
// 	MotorHealth         string  `json:"motorhealth"`
// 	WheelAlignment      string  `json:"wheelalignment"`
// 	InteriorTemperature float64 `json:"interior_temperature"`
// }

type VehicleData struct {
	VehicleId           string  `db:"vehivle_id"`
	Make                string  `db:"make"`
	Model               string  `db:"model"`
	StateOfCharge       float64 `db:"state_of_charge"`
	BatteryVoltage      float64 `db:"battery_voltage"`
	BatteryCurrent      float64 `db:"battery_current"`
	TirePressureFrontL  int     `db:"tirepressurefront_l"`
	TirePressureFrontR  int     `db:"tirepressurefront_r"`
	TirePressureRearR   int     `db:"tirepressurerear_r"`
	TirePressureRearL   int     `db:"tirepressurerear_l"`
	WheelAlignment      string  `db:"wheelalignment"`
	MotorHealth         string  `db:"motorhealth"`
	InverterHealth      string  `db:"inverterhealth"`
	InteriorTemperature float64 `db:"interior_temperature"`
}

type TripDetails struct {
	TripID       string    `db:"trip_id"`
	VehicleID    string    `db:"vehicle_id"`
	StartTime    time.Time `db:"start_time"`
	EndTime      time.Time `db:"end_time"`
	Distance     float64   `db:"distance"`
	MaxSpeed     int       `db:"max_speed"`
	Acceleration int       `db:"acceleration"`
	Deceleration int       `db:"deceleration"`
	AvgSpeed     int       `db:"avg_speed"`
	AvgChargeEff float64   `db:"avg_charge_eff"`
}

type HistoricalData struct {
	VehicleID           string    `db:"vehicle_id"`
	BatteryID           string    `db:"battery_id"`
	State_Of_Charge     int       `db:"state_of_charge"`
	EstimatedRange      int       `db:"estimatedrange"`
	RemainingRange      int       `db:"remaining_range"`
	InteriorTemperature string    `db:"interior_temperature"`
	Latitude            float64   `db:"latitude"`
	Longitude           float64   `db:"longitude"`
	Speed               int       `db:"speed"`
	Voltage             float64   `db:"voltage"`
	Current             float64   `db:"current"`
	Updated_Time        time.Time `db:"updated_time"`
}
type HistoricalDataVol struct {
	VehicleID    string    `db:"vehicle_id"`
	BatteryID    string    `db:"battery_id"`
	Voltage      float64   `db:"voltage"`
	Updated_Time time.Time `db:"updated_time"`
}
type HistoricalDataSOC struct {
	VehicleID       string    `db:"vehicle_id"`
	BatteryID       string    `db:"battery_id"`
	State_Of_Charge int       `db:"state_of_charge"`
	Updated_Time    time.Time `db:"updated_time"`
}
type HistoricalDataER struct {
	VehicleID      string    `db:"vehicle_id"`
	BatteryID      string    `db:"battery_id"`
	EstimatedRange int       `db:"estimatedrange"`
	Updated_Time   time.Time `db:"updated_time"`
}
type HistoricalDataRR struct {
	VehicleID      string    `db:"vehicle_id"`
	BatteryID      string    `db:"battery_id"`
	RemainingRange int       `db:"remaining_range"`
	Updated_Time   time.Time `db:"updated_time"`
}
type HistoricalDataTemp struct {
	VehicleID           string    `db:"vehicle_id"`
	BatteryID           string    `db:"battery_id"`
	InteriorTemperature string    `db:"interior_temperature"`
	Updated_Time        time.Time `db:"updated_time"`
}

type HistoricalDataLoc struct {
	VehicleID    string    `db:"vehicle_id"`
	BatteryID    string    `db:"battery_id"`
	Latitude     float64   `db:"latitude"`
	Longitude    float64   `db:"longitude"`
	Updated_Time time.Time `db:"updated_time"`
}

type HistoricalDataSpeed struct {
	VehicleID    string    `db:"vehicle_id"`
	BatteryID    string    `db:"battery_id"`
	Speed        int       `db:"speed"`
	Updated_Time time.Time `db:"updated_time"`
}

type HistoricalDataCurr struct {
	VehicleID    string    `db:"vehicle_id"`
	BatteryID    string    `db:"battery_id"`
	Current      float64   `db:"current"`
	Updated_Time time.Time `db:"updated_time"`
}
