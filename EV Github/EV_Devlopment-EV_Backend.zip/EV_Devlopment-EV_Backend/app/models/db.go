package models

import (
	"database/sql"
	"log"

	"github.com/go-gorp/gorp"
	_ "github.com/lib/pq" //for postgres
	"github.com/revel/revel"

	eu "github.com/EV_Devlopment/lib/errutil"
)

const (
	MAX_GEO_LEVEL = 8 //max number of levels in geotree
)

var (
	// Dbm is db handle
	Dbm *gorp.DbMap
)

func init() {
	initDB()
	updateModels()
}

func initDB() {
	var dbInfo string

	revel.INFO.Println("RUNNING IN DEV MODE. DATABASE WILL BE LOCAL")
	dbInfo = "port=5432 user=postgres password=12345 dbname=evdatabse sslmode=disable"

	Db, err := sql.Open("postgres", dbInfo)
	if Db == nil || err != nil {
		revel.ERROR.Println("could not connect to postgres", dbInfo)
		panic(err)
	}
	Dbm = &gorp.DbMap{Db: Db, Dialect: gorp.PostgresDialect{}}
	Db.SetMaxIdleConns(5)
}

func updateModels() {

	t := Dbm.AddTableWithName(BatteryPack{}, "batterypack")
	log.Println(t)
	t = Dbm.AddTableWithName(BatteryCell{}, "batterycell")
	t = Dbm.AddTableWithName(ChargeDischargeHistory{}, "chargedischargehistory")
	t = Dbm.AddTableWithName(CycleHistory{}, "cyclehistory")
	t = Dbm.AddTableWithName(AlarmHistory{}, "alarmhistory")
	t = Dbm.AddTableWithName(CellBalancing{}, "cellbalancing")
	t = Dbm.AddTableWithName(AmbientTemperature{}, "ambienttemperature")
	t = Dbm.AddTableWithName(RegenerativeBrakingTable{}, "regenerativebrakingtable")
	t = Dbm.AddTableWithName(Vehicle{}, "vehicle")
	t = Dbm.AddTableWithName(Vehicle_Master{}, "vehicle_master")
	t = Dbm.AddTableWithName(BatteryPack_Master{}, "batterypack_master")
	t = Dbm.AddTableWithName(ChargingHistory{}, "charginghistory")
	t = Dbm.AddTableWithName(RangePrediction{}, "rangeprediction")
	t = Dbm.AddTableWithName(ChargingStation{}, "chargingstation")
	t = Dbm.AddTableWithName(VehicleHealth{}, "vehiclehealth")
	t = Dbm.AddTableWithName(TripDetails{}, "tripdetails")
	t = Dbm.AddTableWithName(HistoricalData{}, "historicaldata")

	Dbm.TraceOn("[gorp]", revel.INFO)
	err := Dbm.CreateTablesIfNotExists()
	eu.CheckErr(err, "Error in creating tables")

}
