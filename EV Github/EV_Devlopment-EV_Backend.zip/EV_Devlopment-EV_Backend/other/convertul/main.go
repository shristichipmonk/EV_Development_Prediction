package main

import (
	"encoding/base64"
	"encoding/csv"
	"encoding/hex"
	"io"
	"log"
	"os"
	"time"
)

func main() {
	if len(os.Args) != 3 {
		log.Println("invalid args")
		return
	}

	iFName, err := os.Open(os.Args[1])
	chkErr(err, "input csv file open failed")
	defer iFName.Close()
	oFName, err := os.Create(os.Args[2])
	chkErr(err, "output csv file open failed")
	defer oFName.Close()

	rc := csv.NewReader(iFName)
	wc := csv.NewWriter(oFName)

	err = wc.Write([]string{"deveui", "uplink_id", "data_frame", "fcnt", "port",
		"timestamp", "rssi", "snr", "sf_used", "cr_used", "device_redundancy", "air_time", "decrypted"})

	loc, err := time.LoadLocation("Asia/Kolkata")
	chkErr(err, "error in getting location")
	const longForm = "2006-01-02T15:04:05.000Z"
	for {
		record, err := rc.Read()
		if err == io.EOF {
			break
		}

		chkErr(err, "error in reading")
		log.Println("record is", record)
		// decode dataFrame
		df, err := base64.StdEncoding.DecodeString(record[2])
		chkErr(err, "error in decoding base64 data: ")
		record[2] = hex.EncodeToString(df)

		currt, err := time.ParseInLocation(longForm, record[5], loc)
		chkErr(err, "error in converting time")
		record[5] = currt.String()
		err = wc.Write(record)
		log.Println("record after is", record)
		wc.Flush()
		chkErr(err, "error in writing to output file")
	}
}

func chkErr(err error, msg string) {
	if err != nil {
		log.Println(msg, err)
		panic(err)
	}
}
