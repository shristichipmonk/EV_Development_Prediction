package main

import (
	"bufio"
	"encoding/binary"
	"fmt"
	"net"
	"os"
	"time"
)

const (
	LightNum  = 40
	Delim     = 0X7E
	HeaderLen = 29

	seqLen = 4

	scu1 = 3453453453451
	scu2 = 3453453453452
	scu3 = 3453453453453
	scu4 = 3453453453454

	RESET = 0X01
)

var (
	seqNum      uint32
	resetTicker = time.NewTicker(time.Second * 2)
	readTicker  = time.NewTicker(time.Millisecond * 100)
)

func init() {
	seqNum = 444444444
}

func main() {
	//Read server address
	if len(os.Args) != 2 {
		fmt.Fprintf(os.Stderr, "Usage %s host:port", os.Args[0])
		os.Exit(1)
	}

	service := os.Args[1]
	tcpAddr, err := net.ResolveTCPAddr("tcp4", service)
	checkError(err)
	fmt.Println("tcpAddr : ", tcpAddr)
	conn, err := net.DialTCP("tcp", nil, tcpAddr)
	checkError(err)
	defer conn.Close()

	fmt.Println("client conn : ", conn)
	reader := bufio.NewReader(conn)
	buf := make([]byte, 1000)
	//i := 0
	for {
		select {
		case <-resetTicker.C:
			data := initHeader(RESET)
			//add 12 offset
			for i := 0; i < 12; i++ {
				data = append(data, byte(0))
			}
			_, err = conn.Write(data)
			checkError(err)
			fmt.Println("Write done", data)
		case <-readTicker.C:
			fmt.Println("start read")
			//	conn.SetReadDeadline(time.Now().Add(time.Millisecond * 50))
			lenght, err := reader.Read(buf)
			checkError(err)
			fmt.Println("received : ", buf[:lenght])
		}
	}
}

func initHeader(payload byte) []byte {
	sgu := []byte("343434")
	data := make([]byte, 0)
	data = append(data, byte(Delim))
	//get len and update
	data = append(data, byte(0))
	data = append(data, byte(22)) //later calculate and change
	data = append(data, sgu...)
	fmt.Println("Current time is ", time.Now().Format("20060102150405"))
	data = append(data, []byte(time.Now().Format("20060102150405"))...)
	data = append(data, convetSeqNum()...)
	data = append(data, byte(0))
	data = append(data, byte(payload))
	return data
}

func convetSeqNum() []byte {
	buf := make([]byte, seqLen)
	binary.BigEndian.PutUint32(buf, seqNum)
	fmt.Println("seq number", buf)
	seqNum++
	return buf
}

func checkError(err error) {
	if err != nil {
		fmt.Fprintf(os.Stderr, " Fatal Error: %s\n", err.Error())
		os.Exit(1)
	}
}
