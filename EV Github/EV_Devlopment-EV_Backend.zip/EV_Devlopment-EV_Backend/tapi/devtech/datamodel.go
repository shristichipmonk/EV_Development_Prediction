package devtech

import(
  "log"
  "encoding/json"
)

const(
  minAstroDataLen := 9
  astroDataSize := 4

  minPhaseDataLen := 7
)

type reqData struct {
	MacID string `json:"MacId"`
}

type respData struct {
	Message []struct {
		AstroScheduleData string
		PhaseScheduleData string
	}
}

// "Message": [{"AstroScheduleData”:”[5,1,1,1],[10,1,255,5]"}]
type astroSchedule struct{
  Time_Interval int
  After_Before int
  Sunrise_Sunset int
  Phase_OnOff int
}

// "Message": [{"PhaseScheduleData”:”[16,0,1],[16,15,8]"}]
type phaseSchedule struct{
  Hours int
  Minutes int
  Phase_OnOff int
}

func  parseAstroScheduleData(asData string) (res string) {
  var astroSchedData []*astroSchedule
  asParts := strings.Split(asData, ",")
  for _, sAstroSchedData := range asParts{
    if len(sAstroSchedData) < minAstroDataSize{
      log.Println("Invalid string encode astro data received, so skipping", sAstroSchedData)
      continue
    }

    // filter [] in data
    dataSlice := strings.Split(sAstroSchedData[1:len(sAstroSchedData)-1], ",")
    if len(dataSlice) != astroDataSize {
      log.Println("Invalid astro data parts received, so skipping", dataSlice)
      continue
    }

    timeInterval, err := strconv.Atoi(dataSlice[0])
    if err != nil{
      log.Println("[astro data]: Invalid time interval received")
      return
    }

    afterBefore, err := strconv.Atoi(dataSlice[1])
    if err != nil{
      log.Println("[astro data]: Invalid after before received")
      return
    }

    sunriseSunset, err := strconv.Atoi(dataSlice[2])
    if err != nil{
      log.Println("[astro data]: Invalid sunrise sunset received")
      return
    }

    phaseOnOff, err := strconv.Atoi(dataSlice[3])
    if err != nil{
      log.Println("[astro data]: Invalid phase on off received")
      return
    }
    astroSchedDatum := &astroSchedule{
      Time_Interval: timeInterval,
      After_Before: afterBefore,
      Sunrise_Sunset: sunriseSunset,
      Phase_OnOff: phaseOnOff,
    }

    astroSchedData = append(astroSchedData, astroSchedDatum)
  }

  basData, _ := json.Marshal(&astroSchedData)
  return string(basData)
}

func  parsePhaseScheduleData(psData string) (res string) {
  var phaseSchedData []*phaseSchedule

  psParts := strings.Split(psData, ",")
  for _, sPhaseSchedData := range psParts{
    if len(sPhaseSchedData) < minPhaseDataSize{
      log.Println("Invalid string encode phase data received, so skipping", sPhaseSchedData)
      continue
    }

    // filter [] in data
    dataSlice := strings.Split(sPhaseSchedData[1:len(sPhaseSchedData)-1], ",")
    if len(dataSlice) != pstroDataSize {
      log.Println("Invalid phase data parts received, so skipping", dataSlice)
      continue
    }

    hours, err := strconv.Atoi(dataSlice[0])
    if err != nil{
      log.Println("[phase data]: Invalid hours value received")
      return
    }

    minutes, err := strconv.Atoi(dataSlice[1])
    if err != nil{
      log.Println("[phase data]: Invalid minutes value received")
      return
    }

    phaseOnOff, err := strconv.Atoi(dataSlice[2])
    if err != nil{
      log.Println("[phase data]: Invalid phase on off received")
      return
    }

    phaseSchedDatum := &phaseSchedule{
      Time_Interval: timeInterval,
      After_Before: afterBefore,
      Sunrise_Sunset: sunriseSunset,
      Phase_OnOff: phaseOnOff,
    }

    phaseSchedData = append(phaseSchedData, phaseSchedDatum)
  }

  bphData, _ := json.Marshal(&phaseSchedData)
  return string(bphData)
}
