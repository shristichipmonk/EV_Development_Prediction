const path = require('path');
const webpack = require('webpack');
require('dotenv').config({
  path :'./.env'
})
module.exports  = {
    entry :  path.resolve(__dirname, 'src', 'index.js'),
    output : {
        filename : "bundle.js",
        path : path.join(__dirname,'public')
    },
    resolve : {
        extensions : [".js",".jsx"],
    },
    module : {
        rules : [
           {
            test : /\.(js|jsx)$/,
            exclude : /node_modules/,
            loader: 'babel-loader',
           },
           {
              test : /\.s?css/,
              use : ['style-loader', 'css-loader','sass-loader']
           },
           {
            test: /\.(png|jpg|gif)$/i,
            use: [
              {
                loader: 'url-loader',
                options: {
                  limit: 8192,
                }
              },
            ],
           type: 'javascript/auto'
          },
        //    {
        //     test: /\.(png|woff|woff2|eot|ttf|svg)$/, // to import images and fonts
        //     loader: "url-loader",
        //     options: { limit: false },
        //   },
        ]
    },
    plugins : [
        new webpack.DefinePlugin({
          "process.env": JSON.stringify(process.env)
        }),
        new webpack.ProvidePlugin({
            React : "react"
        }),
    ],
    cache : false,
    mode: "development",
    devtool: "source-map",
    devServer : {
        port : 8080,
        historyApiFallback : true
    }


}