# Running the EV-application Locally

## Step 1: Set up the Node.js Environment

Make sure you have Node.js installed on your local machine. If not, download and install it from [the official Node.js website](https://nodejs.org/).

## Step 2: Install Dependencies

Open your terminal or command prompt and navigate to the project directory. Then, run the following command to install the required dependencies:
npm i

## Step 3: Create the .env File

Create a file named `.env` in the root directory of the project. Add the following content to the `.env` file:
GOOGLE_API_KEY=AIzaSyDpg6mpWBFZmipiZ9QMiYynednesYCY6FY

## Step 4: Run the Application

Finally, run the following command to start the application:
npm run serve



