// App.js
import React from 'react';
import { BrowserRouter, Route, Routes } from 'react-router-dom';

//style
import '../src/sass/style.scss';
//Pages
import AnalyticalDashboard from './components/Pages/AnalyticalDashboard';
import ChargingStation from './components/Pages/ChargingStation';
import Dashboard from './components/Pages/Dashboard';
import EmailVerification from './components/Pages/EmailVerification';
import ForgotPassword from './components/Pages/ForgotPassword';
import GpsLocator from './components/Pages/GpsLocater';
// import History from './components/Pages/History';
import Login from './components/Pages/Login';
import Register from './components/Pages/Register';
import SafetyNorms from './components/Pages/SafetyNorms';
import Header from './components/header/Header';
import BMS from './components/Pages/BMS';



function App() {
  const loginUser = () =>{
    localStorage.setItem("email",values.email)
  }
  return (
    <div>
      <BrowserRouter>
        <Header/>
        <Routes>
          <Route path="/" element={<Login/>} />
          <Route path="/gpslocator" element={<GpsLocator/>} />
          <Route path="/analytical_dashboard" element={<AnalyticalDashboard />} />
          <Route path="/ChargingStations" element={<ChargingStation/>} />
          <Route path="/history" element={<BMS />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/safetynorms" element={<SafetyNorms />} />
          <Route path="/register" element={<Register />} />
          <Route path="/forgotpassword" element={<ForgotPassword />} />
          <Route path="/emailverification" element={<EmailVerification />} />
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
