export default Product = (a, b) => {
    return a * b;
}