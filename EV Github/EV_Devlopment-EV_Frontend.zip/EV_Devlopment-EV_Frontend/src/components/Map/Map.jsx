import { GoogleMap, InfoWindow, Marker, MarkerClusterer } from "@react-google-maps/api";
import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
// import busIcon from '../../../public/images/bus_icon.png';
// import chargingStnIcon from '../../../public/images/charging_stn.png';
import chargingStnIcon from '../../../public/images/charging_stn_icon.png';
import greenIcon from '../../../public/images/green.png';
import redIcon from '../../../public/images/red.png';
import { getAlarmsForVehicle, getAllVehicleInfo, getChargingStationsInfo } from "../actions";
import './Map.scss';

function Map() {
  const [allVehiclesData, setAllVehieclesData] = useState([]);
  const [chargingStations, setChargingStations] = useState([]);
  const [selectedVehicle, setSelectedVehicle] = useState("");
  const [activeInfo, setActiveInfo] = useState("");
  const [infoWindowPosition, setInfoWindowPosition] = useState(null);

  const mapRef = useRef();
  //Center the map based on data
  const center = useMemo(() => (
     {
      lat: allVehiclesData[0]?allVehiclesData[0].LastKnownLatitude: 0,
      lng: allVehiclesData[0]?allVehiclesData[0].LastKnownLongitude: 0
    } 
    
), [allVehiclesData]);

  //options for the Map
  const options = useMemo(() => ({
    mapId: "7831d40712f22e5c",
    disableDefaultUI: true,
    clickableIcons: false,
  }), []);


  const onLoad = useCallback((map) => {
    (mapRef.current = map)
  }, []);

  //Function for fetch Charging stations onclick on the vehicle or selecting the vehicle
  const fetchChargingStations = async (VehicleId) => {
    if (VehicleId) {
      const charg_stn_data = await getChargingStationsInfo(VehicleId);
      const alerts_data = await getAlarmsForVehicle(VehicleId);
      const { chargingstations, nearestinfo } = charg_stn_data;
      setSelectedVehicle(VehicleId);
      setChargingStations(chargingstations);
      setActiveInfo(
        { near_distnace: nearestinfo, alerts_data: alerts_data.data });
    } else {
      setSelectedVehicle(VehicleId);
      setChargingStations([]);
      setActiveInfo({});
    }
  };

  //Function for fetch vehicles data
  const fetchAllVehiclesInfo = async () => {
    const data = await getAllVehicleInfo();
    setAllVehieclesData(data);
  }

  useEffect(() => {
    fetchAllVehiclesInfo();
  }, []);

  //Function for fetch Charging stations and also display the tool tip of distance
  const handleMarkerClick = (VehicleId) => {
    fetchChargingStations(VehicleId);
    setInfoWindowPosition(VehicleId);
  };

  //Function for returning icons based on threshold info
  const vehicleIcon = (Speed, Batterycapacity, StabilityControlStatus, AbsStatus, RemainingRange, Odometer) => {
    if ( RemainingRange < 10 || AbsStatus == "Off" || StabilityControlStatus == "Off" || Speed > 90  || Odometer > 12000 ) {
      return redIcon;
    }
    else {
      return greenIcon;
    }
  }


  return (
    <div className="gps_cont fluid-container">
      <div className="row" style={{ margin: "0px" }}>
        <div className="gps_cont__controls col-3">
          <h4>Select Vehicle</h4>
          <select className="mt-3 w-100" value={selectedVehicle} onChange={(e) => { fetchChargingStations(e.target.value) }}>
            <option value="">Select...</option>
            {allVehiclesData?.map((charg_stn) => {
              return (
                <option value={charg_stn.VehicleId} key={charg_stn.VehicleId}>{charg_stn.VehicleId}</option>
              )
            })}
          </select>
          {selectedVehicle &&
            <>
              <p className="my-3 text-secondary">Nearest Charging station for {selectedVehicle} is around <span style={{ color: "black", fontWeight: "bold" }}>{activeInfo.near_distnace}</span> Km</p>
            </>
          }
        </div>
        <div className="gps_cont__map col-9">
          <GoogleMap
            zoom={10}
            center={center}
            mapContainerClassName="gps_cont__map-container"
            options={options}
            onLoad={onLoad}
          >
            <>
              {allVehiclesData.map(({ VehicleId, LastKnownLatitude, LastKnownLongitude, Speed, Batteryvoltage, StabilityControlStatus, AbsStatus, TractionControlStatus, ExteriorTemperature, InteriorTemperature, RemainingRange, Acceleration, Odometer, Batterycapacity }) => (
                <Marker
                  data-testid="vehicles"
                  key={VehicleId}
                  position={{ lat: LastKnownLatitude, lng: LastKnownLongitude }}
                  icon={{
                    url: vehicleIcon(Speed, Batteryvoltage, StabilityControlStatus, AbsStatus, TractionControlStatus, Acceleration, Odometer, Batterycapacity,RemainingRange),
                    scaledSize: new window.google.maps.Size(32, 32)
                  }}
                  onClick={() => handleMarkerClick(VehicleId)}
                  title={VehicleId}
                >

                  {infoWindowPosition == VehicleId && (
                    <InfoWindow
                      onCloseClick={() => setInfoWindowPosition(null)}
                    >
                      <div>
                        {selectedVehicle &&
                          <>
                            <p className="my-3 text-secondary">Nearest Charging station for {selectedVehicle} is around <span className="fw-bold">{activeInfo.near_distnace}</span> Km</p>
                            {activeInfo.alerts_data && <p className="text-secondary"> Alarm Reason : <span className="fw-bold">{activeInfo.alerts_data}</span></p>}
                          </>
                        }
                      </div>
                    </InfoWindow>
                  )}
                </Marker>
              ))}
            </>

            <MarkerClusterer>
              {(clusterer) =>
                chargingStations.map((station, index) => (
                  <Marker
                    key={index}
                    position={{ lat: station.Latitude, lng: station.Longitude }}
                    icon={{
                      url: chargingStnIcon,
                      scaledSize: new window.google.maps.Size(50, 50)
                    }}
                    clusterer={clusterer}
                  />
                ))
              }
            </MarkerClusterer>

          </GoogleMap>
        </div>
      </div>
    </div>
  );
}

export default Map;
