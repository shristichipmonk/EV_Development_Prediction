import axios from "axios";

const getSummaryInfo = async () => {
  const result = await axios.get(
    "http://localhost:9011/api/vehicles/allvhicleinfo"
  );
  return result.data;
};

const getVehiclesInfo = async () => {
  const result = await axios.get(
    "http://localhost:9011/api/vehicles/dashboardinfo"
  );
  return result.data;
};

const getAllVehicleInfo = async () => {
  const result = await axios.get(
    "http://localhost:9011/api/vehicles/allvhicleinfo"
  );
  return result.data;
};
const getBMSdetails = async (vehicle_id) => {
  let endpoints = [
    `http://localhost:9011/api/vehicles/${vehicle_id}/battery/telemetry`,
    ` http://localhost:9011/api/vehicles/${vehicle_id}/battery/chargingprofile`,
  ];

  try {
    const [telemetryResponse, chargingProfileResponse] = await axios.all(
      endpoints.map((endpoint) => axios.get(endpoint))
    );

    const { data: telemetry } = telemetryResponse;
    const { data: charging_profile } = chargingProfileResponse;

    return { telemetry, charging_profile };
  } catch (error) {
    console.error("Error fetching data:", error);
    throw error;
  }
};

const getChargingStationsInfo = async (vehicle_Id) => {
  let endpoints = [
    `http://localhost:9011/api/vehicles/${vehicle_Id}/chargingstation`,
    ` http://localhost:9011/api/vehicles/distanceInfo/${vehicle_Id}`,
  ];

  try {
    const [ChargingStationsResponse, nearestResponse] = await axios.all(
      endpoints.map((endpoint) => axios.get(endpoint))
    );

    const { data: chargingstations } = ChargingStationsResponse;
    const { data: nearestinfo } = nearestResponse;

    return { chargingstations, nearestinfo };
  } catch (error) {
    console.error("Error fetching data:", error);
    throw error;
  }
};

const getChargingStations = async () => {
  const result = await axios.get(
    "http://localhost:9011/api/vehicles/All/chargingstation"
  );
  return result.data;
};

const getVehilcleHealth = async (vehicle_id) => {
  const result = await axios.get(
    `http://localhost:9011/api/vehicles/${vehicle_id}/vehiclehealth`
  );
  return result;
};

const getAlarmsForVehicle = async (vehicle_id) => {
  const result = await axios.get(
    `http://localhost:9011/api/vehicles/${vehicle_id}/alarms/`
  );
  return result;
};

const historicaldata = async (formData) => {
  try {
    // Constructing the URL using formData.vehicle_id, formData.start_time, and formData.end_time
    const result = await axios.get(
      `http://localhost:9011/api/vehicles/historicaldata/${formData.vehicle_id}/${formData.start_time}/${formData.end_time}/${formData.parameter}`
    );
    // Returning the Axios response object
    return result;
  } catch (error) {
    // Handling errors by logging them and throwing them further
    console.error("Error fetching historical data:", error);
    throw error;
  }
};

export {
  getAlarmsForVehicle,
  getAllVehicleInfo,
  getBMSdetails,
  getChargingStations,
  getChargingStationsInfo,
  getSummaryInfo,
  getVehiclesInfo,
  getVehilcleHealth,
  historicaldata,
};
