import React, { useEffect, useState } from 'react';
import { useGlobalFilter, usePagination, useTable } from 'react-table';
import SearchInput from './SearchInput';
import './_table.scss';
// import FIlterButton from './FIlterButton';
import { IoIosCloseCircle } from "react-icons/io";
import Pagination from './Pagination';



function InfoTable({ columns, fetchData = null, data = null, expandedrow = null, setExpandedRow, activeTab }) {

  //state variables
  const [tabledata, setTableData] = useState([]);

  //useEffect
  useEffect(() => {
    getVehiclesData();
  }, [fetchData, data, activeTab]);

  // Function to fetch data
  async function getVehiclesData() {
    if (fetchData) {
      const result = await fetchData();
      setTableData(result);
    } else {
      setTableData(data);
    }
  }

  //Table configuration
  const {
    getTableProps,
    getTableBodyProps,
    headerGroups,
    page,
    prepareRow,
    state, setGlobalFilter,
    nextPage, previousPage,
    canPreviousPage,
    canNextPage,
    pageOptions,
    setPageSize,
  } = useTable({
    columns,
    data: tabledata
  }, useGlobalFilter, usePagination);

  const { globalFilter, pageIndex, pageSize } = state;


  return (
    <div>
      <div className="filter_container">
        <SearchInput filter={globalFilter} setFilter={setGlobalFilter} />
        <Pagination
          previousPage={previousPage}
          nextPage={nextPage}
          canNextPage={canNextPage}
          canPreviousPage={canPreviousPage}
          pageOptions={pageOptions}
          pageIndex={pageIndex}
          pageSize={pageSize}
          setPageSize={setPageSize}
        />
      </div>
      <div className="infotable table-wrapper">
        <table {...getTableProps()} >
          <thead>
            {headerGroups.map(headerGroup => (
              <tr {...headerGroup.getHeaderGroupProps()} key={headerGroup}>
                {headerGroup.headers.map(column => (
                  <th
                    key={column.id}
                    {...column.getHeaderProps()}
                    style={{
                      borderBottom: 'solid 1px #c5c5c5',
                    }}
                  >
                    {column.render('Header')}
                  </th>
                ))}
              </tr>
            ))}
          </thead>
          <tbody {...getTableBodyProps()}>
            {page.map(row => {
              prepareRow(row);
              return (
                <React.Fragment key={row.id}>
                  <tr
                    {...row.getRowProps()}
                    onClick={() => setExpandedRow(expandedrow ? null : { id: row.original.VehicleId, title: "Vehicle", data: row.original })}
                    style={{ cursor: 'pointer', backgroundColor: expandedrow && expandedrow.id === row.original.VehicleId ? '#f2f2f2' : 'inherit' }}
                  >
                    {row.cells.map(cell => {
                      return (
                        <td
                          {...cell.getCellProps()}
                        >
                          {cell.render('Cell')}
                        </td>
                      );
                    })}
                  </tr>
                  {expandedrow && expandedrow.id === row.original.VehicleId && (
                    <tr>
                      <td colSpan={columns.length} style={{ background: "#ebebeb" }}>
                        <div className="close_icon">
                          <IoIosCloseCircle onClick={() => setExpandedRow(null)} />
                        </div>
                        <h5 className="my-4 text-secondary">{`${expandedrow.title} Details`}</h5>
                        <div className="expanded_row">
                          {Object.entries(expandedrow.data).map(([key, value]) => (
                            <div key={key}>
                              <h6>{key}</h6>
                              <p>{value}</p>
                            </div>
                          ))}
                        </div>
                      </td>
                    </tr>
                  )}
                </React.Fragment>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default InfoTable;