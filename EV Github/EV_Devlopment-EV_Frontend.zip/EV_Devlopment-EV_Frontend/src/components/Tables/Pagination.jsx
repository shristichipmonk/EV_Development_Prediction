import React, { useRef, useState } from 'react';

function Pagination({previousPage,nextPage, canNextPage, canPreviousPage, pageOptions, pageIndex, pageSize, setPageSize}) {
  const [currentPage, setCurrentPage] = useState(1);

  const totalPages = 5;

  const [visiblePages, setVisiblePages] = useState([1,pageOptions.length]);
  const paginationRef = useRef(null);

  const handlePageChange = (page) => {
    setCurrentPage(page);
    // You can also perform any action here like fetching data for the selected page
  };


  const goToPage = (page) => {
    if (page >= 1 && page <= totalPages) {
      handlePageChange(page);
    }
  };

  const goToPrevPage = () => {
    previousPage()
    goToPage(currentPage - 1);
  };

  const goToNextPage = () => {
    nextPage();
    goToPage(currentPage + 1);
  };


  return (
    <div className="pagination_container">
      <span>Show</span>
      <div>
        <select name="no_results" value={pageSize} onChange={(e)=>{setPageSize(Number(e.target.value))}}>
          {[5,10,13]
            .map((value, index) => {
              return <option key={value} value={value}>{value}</option>;
            })}
        </select>
      </div>
      <div className="pagination" ref={paginationRef}>
        <button className="pagination-btn prev_btn" onClick={()=>{goToPrevPage()}} disabled={!canPreviousPage}>
          &lt;
        </button>
        {(pageOptions).map((page) => (
          <div
            key={page}
            className={`pagination-btn ${currentPage === (page+ 1) ? 'active' : ''}`}
            onClick={() => goToPage(page)}
          >
            {page + 1}
          </div>
        ))}
        <button className="pagination-btn  next_btn" onClick={()=>{goToNextPage()}} disabled={!canNextPage}>
          &gt;
        </button>
      </div>
    </div>
  );
}

export default Pagination;
