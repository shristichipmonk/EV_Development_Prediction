import { useEffect, useState } from "react";
import { validate } from "../../utils/Validation";

const useForm = (callback) => {
  const [values, setValues] = useState({email:"user@gmail.com", password : "User@12345"});
  const [errors, setErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState(null);

  useEffect(() => {
    if (Object.keys(errors).length === 0 && isSubmitting) {
      try {
        callback();
      } catch (error) {
        setSubmitError(error.message);
      }
    }
  }, [errors]);

  const handleSubmit = (event) => {
    // console.log("submitting............")
    if (event) event.preventDefault();
    setErrors(validate(values));
    setIsSubmitting(true);
  };

  const handleChange = (event) => {
    // event.persist();
    // console.log("changing.......")
    setValues((values) => ({
      ...values,
      [event.target.name]: event.target.value,
    }));
  };

  return {
    handleChange,
    handleSubmit,
    values,
    errors,
    submitError,
  };
};

export default useForm;
