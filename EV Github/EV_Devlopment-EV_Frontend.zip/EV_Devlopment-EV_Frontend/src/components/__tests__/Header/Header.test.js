import React, { useEffect } from 'react'
import { fireEvent, getByTestId, render, screen, waitFor } from '@testing-library/react'
import Header from '../../header/Header'
import { BrowserRouter } from 'react-router-dom'
import { AuthProvider } from '../../../Authprovider'
import { useLocation } from 'react-router'
import { log } from 'console'
import { useAuth } from '../../../Authprovider'
jest.mock('../../../Authprovider.js', () => {
    const originalModule = jest.requireActual('../../../Authprovider.js')
    return {
        __esModule: true,
        ...originalModule,
        useAuth: jest.fn(() => ({
            isLoggedIn: true
        }))
    }
})
test("Header should load and render", () => {
    //header should load
    const header = render(<AuthProvider>
        <BrowserRouter>
            <Header />
        </BrowserRouter>
    </AuthProvider>)
    //getting logo 
    const logo = screen.getByTestId("logo")
    // expect(logo).toBeInTheDocument()
    expect(logo.innerHTML).toBe("EV MS")
})
describe("All Nav Items Should Be Present In Header", () => {
    it("gps nav item present", () => {
        render(<AuthProvider>
            <BrowserRouter>
                <Header />
            </BrowserRouter>
        </AuthProvider>)
        expect(screen.getByTestId("nav_gps")).toBeInTheDocument()
    })
    it("analytical dashboard nav item should be present", () => {
        render(<AuthProvider>
            <BrowserRouter>
                <Header />
            </BrowserRouter>
        </AuthProvider>)
        expect(screen.getByTestId("nav_analytical_dashboard")).toBeInTheDocument()
    })
    it(" dashboard nav item should be present", () => {
        render(<AuthProvider>
            <BrowserRouter>
                <Header />
            </BrowserRouter>
        </AuthProvider>)
        expect(screen.getByTestId("nav_dashboard")).toBeInTheDocument()
    })
    it("safety norms nav item should be present", () => {
        render(<AuthProvider>
            <BrowserRouter>
                <Header />
            </BrowserRouter>
        </AuthProvider>)
        expect(screen.getByTestId("nav_safety_norms")).toBeInTheDocument()
    })
    it("charging stations nav item should be present", () => {
        render(<AuthProvider>
            <BrowserRouter>
                <Header />
            </BrowserRouter>
        </AuthProvider>)
        expect(screen.getByTestId("nav_charging_stations")).toBeInTheDocument()
    })
    it("historical data nav item should be present", () => {
        render(<AuthProvider>
            <BrowserRouter>
                <Header />
            </BrowserRouter>
        </AuthProvider>)
        expect(screen.getByTestId("nav_historical_data")).toBeInTheDocument()
    })

})
describe("Testing the Routing part", () => {
    it("should redirect to /gpslocator on click og gps nav item", async () => {
        const { getByTestId } = render(<BrowserRouter>
            <Header />
        </BrowserRouter>
        )
        fireEvent.click(getByTestId("nav_gps"))
        await waitFor(() => {
            expect(window.location.pathname).toEqual("/gpslocator")
        })
    })
    it("should redirect to /analytical_dashboard on click on analytical dashboard nav item", async () => {
        const { getByTestId } = render(<BrowserRouter>
            <Header />
        </BrowserRouter>
        )
        fireEvent.click(getByTestId("nav_analytical_dashboard"))
        await waitFor(() => {
            expect(window.location.pathname).toEqual("/analytical_dashboard")
        })
    })
    it("should redirect to /nav_dashboard on click on  dashboard nav item", async () => {
        const { getByTestId } = render(<BrowserRouter>
            <Header />
        </BrowserRouter>
        )
        fireEvent.click(getByTestId("nav_dashboard"))
        await waitFor(() => {
            expect(window.location.pathname).toEqual("/dashboard")
        })
    })
    it("should redirect to /safetynorms on click on  safetynorms nav item", async () => {
        const { getByTestId } = render(<BrowserRouter>
            <Header />
        </BrowserRouter>
        )
        fireEvent.click(getByTestId("nav_safety_norms"))
        await waitFor(() => {
            expect(window.location.pathname).toEqual("/safetynorms")
        })
    })
    it("should redirect to /history on click on  history nav item", async () => {
        const { getByTestId } = render(<BrowserRouter>
            <Header />
        </BrowserRouter>
        )
        fireEvent.click(getByTestId("nav_historical_data"))
        await waitFor(() => {
            expect(window.location.pathname).toEqual("/history")
        })
    })
    it("should redirect to /ChargingStations on click on  history nav item", async () => {
        const { getByTestId } = render(<BrowserRouter>
            <Header />
        </BrowserRouter>
        )
        fireEvent.click(getByTestId("nav_charging_stations"))
        await waitFor(() => {
            expect(window.location.pathname).toEqual("/ChargingStations")
        })
    })
})