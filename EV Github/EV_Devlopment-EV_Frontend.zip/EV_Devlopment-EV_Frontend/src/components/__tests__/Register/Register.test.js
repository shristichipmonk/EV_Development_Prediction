import React from "react";
import "@testing-library/jest-dom";
import { fireEvent, getByTestId, render, waitFor } from "@testing-library/react";
import Register from "../../Pages/Register";
import { BrowserRouter } from "react-router-dom";

describe("Register component", () => {
  it("renders without crashing", () => {
    render(
      <BrowserRouter>
        <Register />
      </BrowserRouter>
    );
  });
  it("submits form with valid input and navigates to Home", async () => {
    const { getByLabelText, getByTestId } = render(
      <BrowserRouter>
        <Register />
      </BrowserRouter>
    );

    fireEvent.change(getByLabelText("Email address"), {
      target: { value: "test@example.com" },
    });
    fireEvent.change(getByLabelText("Password"), {
      target: { value: "Password123!" },
    });

    fireEvent.click(getByTestId("signin-btn"));

    await waitFor(() => expect(window.location.pathname).toEqual("/"));
  });

  it("should return error for invalid email and weak password for Register", async () => {
    const { getByLabelText, getByText,getByTestId } = render(
      <BrowserRouter>
        <Register />
      </BrowserRouter>
    );
  
    fireEvent.change(getByLabelText("Email address"), {
      target: { value: "invalid_email" },
    });
    fireEvent.change(getByLabelText("Password"), { target: { value: "weak" } });
  
    fireEvent.click(getByTestId("signin-btn"));
  
    await waitFor(() => {
      expect(getByText("Email address is invalid")).toBeInTheDocument();
      expect(getByText("Password must be 8 or more characters")).toBeInTheDocument();
    });
  });
  
  it("should return error for password without at least one number for Register", async () => {
    const { getByLabelText, getByText,getByTestId } = render(
      <BrowserRouter>
        <Register />
      </BrowserRouter>
    );
  
    fireEvent.change(getByLabelText("Email address"), {
      target: { value: "user@gmail.com" },
    });
    fireEvent.change(getByLabelText("Password"), { target: { value: "Testuser" } });
  
    fireEvent.click(getByTestId("signin-btn"));
  
    await waitFor(() => {
      expect(getByText("Password must contain at least 1 number")).toBeInTheDocument();
    });
  });

  it("should return error for password without at least one Special Character for Register", async () => {
    const { getByLabelText, getByText,getByTestId } = render(
      <BrowserRouter>
        <Register />
      </BrowserRouter>
    );
  
    fireEvent.change(getByLabelText("Email address"), {
      target: { value: "user@gmail.com" },
    });
    fireEvent.change(getByLabelText("Password"), { target: { value: "user12345" } });
  
    fireEvent.click(getByTestId("signin-btn"));
  
    await waitFor(() => {
      expect(getByText("Password must contain at least 1 special character")).toBeInTheDocument();
    });
  });
  
  it("should return error for password without at least one capital letter for Register", async () => {
    const { getByLabelText, getByText,getByTestId } = render(
      <BrowserRouter>
        <Register />
      </BrowserRouter>
    );
  
    fireEvent.change(getByLabelText("Email address"), {
      target: { value: "user@gmail.com" },
    });
    fireEvent.change(getByLabelText("Password"), { target: { value: "user@12345" } });
  
    fireEvent.click(getByTestId("signin-btn"));
  
    await waitFor(() => {
      expect(getByText("Password must contain at least 1 capital letter")).toBeInTheDocument();
    });
  });
  


  it('should redirect to the Login page by clicking "Already have an account"', async () => {
    const { getByText, } = render(
      <BrowserRouter>
        <Register />
      </BrowserRouter>
    );

    fireEvent.click(getByText("Already have an account"));

    await waitFor(() => {
      console.log(window.location.pathname);
      expect(window.location.pathname).toEqual("/");
    });
  });

  it('password visibility toggles when the icon is clicked', async ()=>{
    const {getByLabelText,getByTestId} = render(
        <BrowserRouter>
          <Register />
        </BrowserRouter>
    )
    const passwordElem = getByLabelText('Password');

    expect(passwordElem.type).toBe('password');
   
    fireEvent.click(getByTestId('visbility-icon'))
    expect(passwordElem.type).toBe('text');

    fireEvent.click(getByTestId('visbility-icon'))
    expect(passwordElem.type).toBe('password');

  })
});
