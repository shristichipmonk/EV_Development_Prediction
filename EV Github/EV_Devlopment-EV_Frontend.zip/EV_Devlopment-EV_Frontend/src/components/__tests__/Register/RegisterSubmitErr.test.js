import '@testing-library/jest-dom';
import { fireEvent, render, waitFor } from '@testing-library/react';
import React from 'react';
import { BrowserRouter } from 'react-router-dom';
// import { MemoryRouter } from 'react-router-dom';
import Register from '../../Pages/Register';


jest.mock('../../customHooks/useForm.js', () => {
  const originalModule = jest.requireActual('../../customHooks/useForm.js');
  console.log(originalModule);
  return {
    __esModule: true,
    ...originalModule,
    default: jest.fn(() => ({
      values: {email:'user@gmail.com', password:'User@12345'},
      errors: {},
      handleChange: originalModule.default().handleChange, 
      handleSubmit: originalModule.default().handleSubmit, 
      submitError: "Error message"
    })),
  };
});

  it("should test submit error for Register", async () => {
    const { getByText } = render(
      <BrowserRouter>
        <Register />
      </BrowserRouter>
    );

    fireEvent.click(getByText('Signin'));

    await waitFor(() => {
      expect(getByText("Error message")).toBeInTheDocument();
    });
  });

