import React from 'react';
import '@testing-library/jest-dom';
import {render, fireEvent, waitFor,screen } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import GpsLocator from '../../../components/Pages/GpsLocater'
import { useLoadScript } from "@react-google-maps/api";




// Mocking the Google Maps API
jest.mock('@react-google-maps/api', () => {
    const originalModule = jest.requireActual('@react-google-maps/api');
    
    // Mocked implementation for GoogleMap component
    const MockGoogleMap = (props) => {
      const { children } = props;
      return <div>{children}</div>;
    };
  
    // Mocked implementation for Marker component
    const MockMarker = (props) => {
      return <div>{props.children}</div>;
    };
  
    // Mocked implementation for InfoWindow component
    const MockInfoWindow = (props) => {
      return <div>{props.children}</div>;
    };
  
    // // Mocked implementation for window.google object
    // const google = {
    //   maps: {
    //     Size: jest.fn(),
    //   }
    // };
  
    return {
      __esModule: true,
      ...originalModule,
      GoogleMap: MockGoogleMap,
      Marker: MockMarker,
      InfoWindow: MockInfoWindow,
      useLoadScript:jest.fn(),
    };
  });
  
  
  describe('GpsLocater', () => {
    it('renders loading message when not loaded', () => {
      // Mocking isLoaded to be false
      require('@react-google-maps/api').useLoadScript.mockImplementation(() => ({
        isLoaded: false,
      }));  
      const { getByText } = render(
        <BrowserRouter>
              <GpsLocator />;
        </BrowserRouter>
      )
      expect(getByText('Loading...')).toBeInTheDocument();
    });
  
    it('renders Map when loaded', () => {
      // Mocking isLoaded to be true
      require('@react-google-maps/api').useLoadScript.mockImplementation(() => ({
        isLoaded: true,
      }));  
      const { queryByText }  = render(
        <BrowserRouter>
           <GpsLocator />;
        </BrowserRouter>
      );
      expect(queryByText ('Loading...')).toBeNull();
    });
  });