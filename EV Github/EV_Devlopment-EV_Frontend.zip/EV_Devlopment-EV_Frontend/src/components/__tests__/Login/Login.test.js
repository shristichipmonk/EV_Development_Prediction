import React from 'react';
import '@testing-library/jest-dom';
import Login from '../../Pages/Login';
import { render, fireEvent, waitFor } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import { useAuth } from '../../../Authprovider';


jest.mock('../../../Authprovider',()=>{
    const originalModule = jest.requireActual('../../../Authprovider');
    return {
        __esModule: true,
        ...originalModule,
        useAuth : jest.fn(() => ({
            isLoggedIn: false,
          })),
    }
})


describe('Login Component Testing', () => {
  it('renders Login without crashing', () => {
    render(
      <BrowserRouter>
        <Login />
      </BrowserRouter>
    );
  });

  it('submits form with valid input and navigates to Home  for Login', async () => {
    const { getByLabelText, getByTestId } = render(
      <BrowserRouter>
        <Login />
      </BrowserRouter>
    );

    fireEvent.change(getByLabelText('Email address'), {
      target: { value: 'test@example.com' },
    });
    fireEvent.change(getByLabelText('Password'), {
      target: { value: 'Password123!' },
    });

    fireEvent.click(getByTestId('login-btn'));

    await waitFor(() => expect(window.location.pathname).toEqual('/'));
  });

  it('should return error for invalid inputs  for Login', async () => {
    const { getByLabelText, getByText,getByTestId } = render(
      <BrowserRouter>
        <Login />
      </BrowserRouter>
    );

    fireEvent.change(getByLabelText('Email address'), {
      target: { value: 'invalid_email' },
    });
    fireEvent.change(getByLabelText('Password'), { target: { value: 'weak' } });

    fireEvent.click(getByTestId('login-btn'));

    await waitFor(() => {
      expect(getByText('Email address is invalid')).toBeInTheDocument();
      expect(getByText('Password must be 8 or more characters')).toBeInTheDocument();
    });
  });
  it("should return error for password without at least one number for Login", async () => {
    const { getByLabelText, getByText,getByTestId } = render(
      <BrowserRouter>
         <Login />
      </BrowserRouter>
    );
  
    fireEvent.change(getByLabelText("Email address"), {
      target: { value: "user@gmail.com" },
    });
    fireEvent.change(getByLabelText("Password"), { target: { value: "Testuser" } });
  
    fireEvent.click(getByTestId('login-btn'));
  
    await waitFor(() => {
      expect(getByText("Password must contain at least 1 number")).toBeInTheDocument();
    });
  });

  it("should return error for password without at least one Special Character for Login", async () => {
    const { getByLabelText, getByText,getByTestId } = render(
      <BrowserRouter>
         <Login />
      </BrowserRouter>
    );
  
    fireEvent.change(getByLabelText("Email address"), {
      target: { value: "user@gmail.com" },
    });
    fireEvent.change(getByLabelText("Password"), { target: { value: "user12345" } });
  
    fireEvent.click(getByTestId('login-btn'));
  
    await waitFor(() => {
      expect(getByText("Password must contain at least 1 special character")).toBeInTheDocument();
    });
  });
  
  it("should return error for password without at least one capital letter for Login", async () => {
    const { getByLabelText, getByText,getByTestId } = render(
      <BrowserRouter>
         <Login />
      </BrowserRouter>
    );
  
    fireEvent.change(getByLabelText("Email address"), {
      target: { value: "user@gmail.com" },
    });
    fireEvent.change(getByLabelText("Password"), { target: { value: "user@12345" } });
  
    fireEvent.click(getByTestId('login-btn'));
  
    await waitFor(() => {
      expect(getByText("Password must contain at least 1 capital letter")).toBeInTheDocument();
    });
  });
  
});
