import React from 'react';
import '@testing-library/jest-dom';
import Login from '../../Pages/Login';
import {render, fireEvent, waitFor,screen} from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import { useAuth } from '../../../Authprovider';
import { act } from 'react-dom/test-utils';


jest.mock('../../../Authprovider',()=>{
    const originalModule = jest.requireActual('../../../Authprovider');
    return {
        __esModule: true,
        ...originalModule,
        useAuth : jest.fn(() => ({
            isLoggedIn: false,
          })),
    }
})

jest.mock('../../customHooks/useForm.js', () => {
    const originalModule = jest.requireActual('../../customHooks/useForm.js');
    console.log(originalModule);
    return {
      __esModule: true,
      ...originalModule,
      default: jest.fn(() => ({
        values: {email:'user@gmail.com', password:'User@12345'},
        errors: {},
        handleChange: originalModule.default().handleChange, 
        handleSubmit: originalModule.default().handleSubmit, 
        submitError: "Error message"
      })),
    };
  });

it('should test submit error', async()=>{
    await act(async ()=>
    render(
        <BrowserRouter>
          <Login />
        </BrowserRouter>
    )
    )

    fireEvent.click(screen.getByText('Login'));
    expect(screen.getByText('Error message')).toBeInTheDocument();
})