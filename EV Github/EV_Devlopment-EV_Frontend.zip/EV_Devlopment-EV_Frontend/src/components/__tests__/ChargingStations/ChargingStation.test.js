import React from 'react';
import '@testing-library/jest-dom';
import {render, fireEvent, waitFor, screen} from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import { act } from 'react-dom/test-utils';
import ChargingStation from '../../Pages/ChargingStation';

jest.mock('../../actions', () => ({
    getChargingStations: jest.fn().mockResolvedValue([
        {
            "Id": 18,
            "Name": "Station_37",
            "Latitude": 28.585305,
            "Longitude": 77.191,
            "Power_Available": 15,
            "Num_Docks": 5
        },
        {
            "Id": 15,
            "Name": "Station_30",
            "Latitude": 28.63363,
            "Longitude": 77.220579,
            "Power_Available": 15,
            "Num_Docks": 7
        },
        {
            "Id": 5,
            "Name": "Station_8",
            "Latitude": 28.630448,
            "Longitude": 77.225557,
            "Power_Available": 15,
            "Num_Docks": 6
        },
        {
            "Id": 22,
            "Name": "Station_70",
            "Latitude": 28.54639,
            "Longitude": 77.196354,
            "Power_Available": 15,
            "Num_Docks": 7
        },
        {
            "Id": 7,
            "Name": "Station_10",
            "Latitude": 28.600333,
            "Longitude": 77.226888,
            "Power_Available": 15,
            "Num_Docks": 6
        },
        {
            "Id": 8,
            "Name": "Station_10",
            "Latitude": 28.63367,
            "Longitude": 77.223492,
            "Power_Available": 15,
            "Num_Docks": 6
        },
        {
            "Id": 10,
            "Name": "Station_21",
            "Latitude": 28.577231,
            "Longitude": 77.197238,
            "Power_Available": 15,
            "Num_Docks": 6
        },
        {
            "Id": 11,
            "Name": "Station_22",
            "Latitude": 28.633797,
            "Longitude": 77.217455,
            "Power_Available": 15,
            "Num_Docks": 6
        },
        {
            "Id": 12,
            "Name": "Station_23",
            "Latitude": 28.583804,
            "Longitude": 77.221822,
            "Power_Available": 15,
            "Num_Docks": 6
        },
        {
            "Id": 16,
            "Name": "Station_31",
            "Latitude": 28.632989,
            "Longitude": 77.21798,
            "Power_Available": 15,
            "Num_Docks": 5
        },
        {
            "Id": 17,
            "Name": "Station_32",
            "Latitude": 28.634071,
            "Longitude": 77.218779,
            "Power_Available": 15,
            "Num_Docks": 5
        },
        {
            "Id": 19,
            "Name": "Station_38",
            "Latitude": 28.622224,
            "Longitude": 77.214249,
            "Power_Available": 15,
            "Num_Docks": 7
        },
        {
            "Id": 20,
            "Name": "Station_39",
            "Latitude": 28.602356,
            "Longitude": 77.186617,
            "Power_Available": 15,
            "Num_Docks": 7
        },
        {
            "Id": 21,
            "Name": "Station_40",
            "Latitude": 28.585287,
            "Longitude": 77.177093,
            "Power_Available": 15,
            "Num_Docks": 7
        },
        {
            "Id": 23,
            "Name": "Station_71",
            "Latitude": 28.545394,
            "Longitude": 77.190822,
            "Power_Available": 15,
            "Num_Docks": 5
        },
        {
            "Id": 24,
            "Name": "Station_72",
            "Latitude": 28.550013,
            "Longitude": 77.24487,
            "Power_Available": 15,
            "Num_Docks": 8
        },
        {
            "Id": 2,
            "Name": "Station_3",
            "Latitude": 28.588303,
            "Longitude": 77.217697,
            "Power_Available": 15,
            "Num_Docks": 3
        },
        {
            "Id": 3,
            "Name": "Station_4",
            "Latitude": 28.582653,
            "Longitude": 77.220087,
            "Power_Available": 15,
            "Num_Docks": 3
        },
        {
            "Id": 4,
            "Name": "Station_5",
            "Latitude": 28.584485,
            "Longitude": 77.220315,
            "Power_Available": 15,
            "Num_Docks": 4
        },
        {
            "Id": 6,
            "Name": "Station_9",
            "Latitude": 28.583882,
            "Longitude": 77.163408,
            "Power_Available": 15,
            "Num_Docks": 4
        },
        {
            "Id": 1,
            "Name": "Station_1",
            "Latitude": 28.600725,
            "Longitude": 77.226252,
            "Power_Available": 15,
            "Num_Docks": 5
        },
        {
            "Id": 9,
            "Name": "Station_11",
            "Latitude": 28.6317294,
            "Longitude": 77.2221076,
            "Power_Available": 15,
            "Num_Docks": 6
        },
        {
            "Id": 14,
            "Name": "Station_25",
            "Latitude": 28.617782,
            "Longitude": 77.212995,
            "Power_Available": 15,
            "Num_Docks": 6
        }
    ])
})
);
describe('Charging Stations Component Testing', () => {
    it('renders Charging Stations without crashing', async() => {
        await act(async ()=>{
            render(
                <BrowserRouter>
                   <ChargingStation/>
                </BrowserRouter>
            )
        })

    }
    )

    it('displays table columns properly', async () => {
        await act(async () => {
          render(
            <BrowserRouter>
              <ChargingStation />
            </BrowserRouter>
          );
        });
      
        // Assuming ChargingStation fetches data for columns      
        expect(screen.getByText('ID')).toBeInTheDocument();
        expect(screen.getByText('Name')).toBeInTheDocument();
        expect(screen.getByText('Latitude')).toBeInTheDocument();
        expect(screen.getByText('Longitude')).toBeInTheDocument();
        expect(screen.getByText('Power Available')).toBeInTheDocument();
        expect(screen.getByText('Number of Docks')).toBeInTheDocument();
      });

      it('Should contain all the rows', async()=>{
        await act(async()=>{
            render(
                <BrowserRouter>
                <ChargingStation/>
              </BrowserRouter>
            )
        })

        expect(screen.getAllByTestId("row_element").length).toBe(10)
   })
})
