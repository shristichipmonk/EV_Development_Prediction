import React from 'react';
import '@testing-library/jest-dom';
import {render, fireEvent, waitFor, screen} from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import SafetyNorms from '../../Pages/SafetyNorms';
import { act } from 'react-dom/test-utils';

describe('SafetyNorms Component Testing', () => {
    it('renders SafetyNorms without crashing', async() => {
        await act(async ()=>{
            render(
                <BrowserRouter>
                   <SafetyNorms/>
                </BrowserRouter>
            )
        })

    }
    )

    it('displays table columns properly', async() => {
       await act(async ()=>{
            render(
                <BrowserRouter>
                   <SafetyNorms/>
                </BrowserRouter>
            )
        })
    
        // Asserting that all table columns are rendered
        expect(screen.getByText('Norms ID')).toBeInTheDocument();
        expect(screen.getByText('Norms Name')).toBeInTheDocument();
        expect(screen.getByText('Description')).toBeInTheDocument();
        expect(screen.getByText('Severity')).toBeInTheDocument();
        expect(screen.getByText('Threshold values')).toBeInTheDocument();
        expect(screen.getByText('Threshold Unit')).toBeInTheDocument();
        expect(screen.getByText('Applied Component')).toBeInTheDocument();
        expect(screen.getByText('Frequency')).toBeInTheDocument();
        expect(screen.getByText('Last Checked')).toBeInTheDocument();
    }
    )

    it('Should contain all the rows', async()=>{
        await act(async()=>{
            render(
                <BrowserRouter>
                <SafetyNorms/>
              </BrowserRouter>
            )
        })

        expect(screen.getAllByTestId("row_element").length).toBe(4)
   })

})
