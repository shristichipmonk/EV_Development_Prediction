import React from 'react';
import '@testing-library/jest-dom';
import {render, fireEvent, waitFor,screen } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import Map from '../../Map/Map';
import { GoogleMap, InfoWindow, Marker, MarkerClusterer } from "@react-google-maps/api";
import { act } from 'react-dom/test-utils';
// Mock google object
// global.google = {
//     maps: {
//       Map: jest.fn(()=> ({
//         setCenter: jest.fn(),
//         setOptions:jest.fn(),
//         setZoom:jest.fn(),
//       }),),
//       // MarkerClusterer: jest.fn(() => ({
//       //   addMarker: jest.fn(),
//       // })),
//       Marker: jest.fn(() => ({
//         addListener: jest.fn(),
//       })),
//       InfoWindow: jest.fn(() => ({
//         open: jest.fn(),
//         close: jest.fn(),
//       })),
//       LatLng: jest.fn(),
//     },
//   };

  // jest.mock('@react-google-maps/api', () => ({
  //   ...jest.requireActual('@react-google-maps/api'),
  //   MarkerClusterer: jest.fn(({ children }) => <div>{children}</div>),
  //   GoogleMap : jest.fn(({ children }) => <div>{children}</div>),
  //   Map: jest.fn(({ children }) => <div>{children}</div>),
  //   Marker:jest.fn(({ children }) => <div>{children}</div>),
  //   InfoWindow: jest.fn(({ children }) => <div>{children}</div>),
  //   LatLng:jest.fn(({ children }) => <div>{children}</div>),
  // }));
  
  jest.mock('@react-google-maps/api', () => ({
    ...jest.requireActual('@react-google-maps/api'),
    MarkerClusterer: jest.fn(({ children }) => <div>{children}</div>),
    GoogleMap: jest.fn(({ children }) => <div>{children}</div>),
    Map: jest.fn(({ children }) => <div>{children}</div>),
    Marker: jest.fn(({ children }) => <div>{children}</div>),
    InfoWindow: jest.fn(({ children }) => <div>{children}</div>),
    LatLng: jest.fn(({ children }) => <div>{children}</div>),
  }));
// jest.mock('@react-google-maps/api', () => ({
//   ...jest.requireActual('@react-google-maps/api'),
//   GoogleMap: function () {
//     return {
//       setCenter: jest.fn(),
//       setOptions: jest.fn(),
//       setZoom: jest.fn(),
//     };
//   },
// }));


  jest.mock('../../actions', () => ({
    getAllVehicleInfo: jest.fn().mockResolvedValue([
        {
            "VehicleId": "V68F1",
            "VehicleName": "Chevrolet Bolt",
            "ManufactureYear": 2021,
            "Model": "Bolt EV",
            "Batterycapacity": 22000,
            "Batteryvoltage": 480,
            "Batterycurrent": 45,
            "StateOfCharge": 95,
            "ChargingStatus": "Charging",
            "EstimatedRange": 350,
            "RemainingRange": 180,
            "Motortype": "Electric",
            "MotorPower": 180,
            "Motortorque": 280,
            "InteriorTemperature": 18,
            "ExteriorTemperature": 22,
            "LastKnownLatitude": 28.644736,
            "LastKnownLongitude": 77.193369,
            "LastKnownTimestamp": "2024-02-19T10:33:00+05:30",
            "AirbagStatus": "Deployed",
            "AbsStatus": "On",
            "TractionControlStatus": "On",
            "StabilityControlStatus": "On",
            "Speed": 75,
            "Acceleration": 20,
            "Odometer": 8000,
            "InformationSystemStatus": "Functional",
            "WiperStatus": "On",
            "HornStatus": "On",
            "LightingSystemStatus": "Functional",
            "LastUpdateTime": "2024-02-19T10:33:00+05:30"
        },
        {
            "VehicleId": "V71X3",
            "VehicleName": "Audi e-tron",
            "ManufactureYear": 2019,
            "Model": "e-tron SUV",
            "Batterycapacity": 21000,
            "Batteryvoltage": 460,
            "Batterycurrent": 42,
            "StateOfCharge": 92,
            "ChargingStatus": "Charging",
            "EstimatedRange": 320,
            "RemainingRange": 160,
            "Motortype": "Electric",
            "MotorPower": 160,
            "Motortorque": 260,
            "InteriorTemperature": 21,
            "ExteriorTemperature": 26,
            "LastKnownLatitude": 28.60294,
            "LastKnownLongitude": 77.195065,
            "LastKnownTimestamp": "2024-02-19T10:37:00+05:30",
            "AirbagStatus": "Deployed",
            "AbsStatus": "On",
            "TractionControlStatus": "On",
            "StabilityControlStatus": "On",
            "Speed": 72,
            "Acceleration": 16,
            "Odometer": 7500,
            "InformationSystemStatus": "Functional",
            "WiperStatus": "On",
            "HornStatus": "On",
            "LightingSystemStatus": "Functional",
            "LastUpdateTime": "2024-02-19T10:37:00+05:30"
        },
        {
            "VehicleId": "V7V2M",
            "VehicleName": "Tesla Model S",
            "ManufactureYear": 2020,
            "Model": "Model S",
            "Batterycapacity": 20000,
            "Batteryvoltage": 450,
            "Batterycurrent": 40,
            "StateOfCharge": 80,
            "ChargingStatus": "Discharging",
            "EstimatedRange": 300,
            "RemainingRange": 150,
            "Motortype": "Electric",
            "MotorPower": 150,
            "Motortorque": 250,
            "InteriorTemperature": 20,
            "ExteriorTemperature": 25,
            "LastKnownLatitude": 28.578088,
            "LastKnownLongitude": 77.189885,
            "LastKnownTimestamp": "2024-02-19T10:31:00+05:30",
            "AirbagStatus": "Deployed",
            "AbsStatus": "On",
            "TractionControlStatus": "On",
            "StabilityControlStatus": "On",
            "Speed": 70,
            "Acceleration": 15,
            "Odometer": 7000,
            "InformationSystemStatus": "Functional",
            "WiperStatus": "On",
            "HornStatus": "On",
            "LightingSystemStatus": "Functional",
            "LastUpdateTime": "2024-02-19T10:31:00+05:30"
        },
        {
            "VehicleId": "V8ETX",
            "VehicleName": "BMW i3",
            "ManufactureYear": 2017,
            "Model": "i3",
            "Batterycapacity": 16000,
            "Batteryvoltage": 400,
            "Batterycurrent": 30,
            "StateOfCharge": 90,
            "ChargingStatus": "Discharging",
            "EstimatedRange": 200,
            "RemainingRange": 100,
            "Motortype": "Electric",
            "MotorPower": 100,
            "Motortorque": 200,
            "InteriorTemperature": 25,
            "ExteriorTemperature": 30,
            "LastKnownLatitude": 28.554777,
            "LastKnownLongitude": 77.186107,
            "LastKnownTimestamp": "2024-02-19T10:35:00+05:30",
            "AirbagStatus": "Deployed",
            "AbsStatus": "On",
            "TractionControlStatus": "On",
            "StabilityControlStatus": "On",
            "Speed": 60,
            "Acceleration": 10,
            "Odometer": 5000,
            "InformationSystemStatus": "Functional",
            "WiperStatus": "On",
            "HornStatus": "On",
            "LightingSystemStatus": "Functional",
            "LastUpdateTime": "2024-02-19T10:35:00+05:30"
        },
        {
            "VehicleId": "V0Z1D",
            "VehicleName": "Toyota Prius",
            "ManufactureYear": 2019,
            "Model": "Prius Prime",
            "Batterycapacity": 16000,
            "Batteryvoltage": 400,
            "Batterycurrent": 30,
            "StateOfCharge": 90,
            "ChargingStatus": "Charging",
            "EstimatedRange": 200,
            "RemainingRange": 100,
            "Motortype": "Electric",
            "MotorPower": 100,
            "Motortorque": 200,
            "InteriorTemperature": 25,
            "ExteriorTemperature": 30,
            "LastKnownLatitude": 28.591084,
            "LastKnownLongitude": 77.22762,
            "LastKnownTimestamp": "2024-02-19T10:30:00+05:30",
            "AirbagStatus": "Deployed",
            "AbsStatus": "On",
            "TractionControlStatus": "On",
            "StabilityControlStatus": "On",
            "Speed": 60,
            "Acceleration": 10,
            "Odometer": 5000,
            "InformationSystemStatus": "Functional",
            "WiperStatus": "Off",
            "HornStatus": "On",
            "LightingSystemStatus": "Functional",
            "LastUpdateTime": "2024-02-19T10:30:00+05:30"
        },
        {
            "VehicleId": "VDL68",
            "VehicleName": "Mercedes-Benz EQC",
            "ManufactureYear": 2020,
            "Model": "EQC 400",
            "Batterycapacity": 22000,
            "Batteryvoltage": 480,
            "Batterycurrent": 45,
            "StateOfCharge": 95,
            "ChargingStatus": "Discharging",
            "EstimatedRange": 350,
            "RemainingRange": 180,
            "Motortype": "Electric",
            "MotorPower": 180,
            "Motortorque": 280,
            "InteriorTemperature": 18,
            "ExteriorTemperature": 22,
            "LastKnownLatitude": 28.597619,
            "LastKnownLongitude": 77.206715,
            "LastKnownTimestamp": "2024-02-19T10:36:00+05:30",
            "AirbagStatus": "Deployed",
            "AbsStatus": "On",
            "TractionControlStatus": "On",
            "StabilityControlStatus": "On",
            "Speed": 75,
            "Acceleration": 20,
            "Odometer": 8000,
            "InformationSystemStatus": "Functional",
            "WiperStatus": "Off",
            "HornStatus": "On",
            "LightingSystemStatus": "Functional",
            "LastUpdateTime": "2024-02-19T10:36:00+05:30"
        },
        {
            "VehicleId": "V9Z2J",
            "VehicleName": "Volvo XC40 Recharge",
            "ManufactureYear": 2022,
            "Model": "XC40 Recharge",
            "Batterycapacity": 21000,
            "Batteryvoltage": 460,
            "Batterycurrent": 42,
            "StateOfCharge": 92,
            "ChargingStatus": "Charging",
            "EstimatedRange": 320,
            "RemainingRange": 160,
            "Motortype": "Electric",
            "MotorPower": 160,
            "Motortorque": 260,
            "InteriorTemperature": 21,
            "ExteriorTemperature": 26,
            "LastKnownLatitude": 28.520055,
            "LastKnownLongitude": 77.205569,
            "LastKnownTimestamp": "2024-02-19T10:40:00+05:30",
            "AirbagStatus": "Deployed",
            "AbsStatus": "On",
            "TractionControlStatus": "On",
            "StabilityControlStatus": "On",
            "Speed": 150,
            "Acceleration": 20,
            "Odometer": 5000,
            "InformationSystemStatus": "Functional",
            "WiperStatus": "Off",
            "HornStatus": "On",
            "LightingSystemStatus": "Functional",
            "LastUpdateTime": "2024-03-19T10:36:00+05:30"
        }
    ]),
    getChargingStationsInfo: jest.fn().mockResolvedValue({
      chargingstations: [
        {
          Latitude: 37.7749,
          Longitude: -122.4194,
          // Add other properties as needed for testing
        },
      ],
      nearestinfo: '1',
      data: 'Some alerts data',
    }),
  }));
  describe('Map Component Testing', () => {
    it('renders Map without crashing', async() => {
      await act(async () => {
        try {
          render(
            <BrowserRouter>
              <Map />
            </BrowserRouter>
          );
        } catch (error) {
          console.error("Error rendering Map component:", error);
        }
      });
    });

    // it('testing',async()=>{
    //   await act(()=>
    //      render(
    //       <BrowserRouter>
    //         <Map />
    //       </BrowserRouter>
    //      )
    //   )
    //   expect(screen.getAllByTestId('vehicles').length.toBe(7))
    // })
  });