import React from 'react';
import { Col, Container,Row } from 'react-bootstrap';
import OtpInput from '../otp/OtpInput';

function EmailVerification() {
  return (
    <Container className="email_verif_container">
      <Row className="justify-content-center">
        <Col md={6} className="email_verif_container__column">
          <h3 className='email_verif_container__head'>Verify OTP</h3>
          <p className='text-center text-secondary'>Please enter the 4 digit code that send to your Email address</p>
          <OtpInput otpLength={4}/>
        </Col>
      </Row>
    </Container>
  )
}

export default EmailVerification