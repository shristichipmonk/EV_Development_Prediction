import { faEnvelope } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import React, { useState } from 'react';
import { Col, Container, FloatingLabel, Form, InputGroup, Row } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';

function ForgotPassword() {
    const [email,setEmail] = useState('');
    const navigate = useNavigate();

    const submitHandler = ()=>{
        navigate('/emailverification');
    }
  return (
    <Container className="forgot_pwd_container">
      <Row className="justify-content-center">
        <Col md={6} className="forgot_pwd_container__column">
          <h3 className="forgot_pwd_container__head">Mail Address Here</h3>
          <p className="text-center text-secondary" style={{marginBottom:"2rem"}}>Enter the email address associated with your account</p>
          <Form onSubmit={submitHandler}>
            <FloatingLabel controlId="floatingInput"  className="mb-3">
              <InputGroup>
                <InputGroup.Text><FontAwesomeIcon icon={faEnvelope} /></InputGroup.Text>
                <Form.Control size="lg" type="email" value={email} onChange={(e)=>{setEmail(e.target.value)}} placeholder="name@example.com" />
              </InputGroup>
            </FloatingLabel>
            <div className="text-center mt-3">
                <button>
                    Recover Password
                 </button>
            </div>
          </Form> 
        </Col>
      </Row>
    </Container>
  )
}

export default ForgotPassword;
