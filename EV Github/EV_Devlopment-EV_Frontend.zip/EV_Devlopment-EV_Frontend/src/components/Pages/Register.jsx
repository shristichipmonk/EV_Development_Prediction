import React, { useState } from 'react';
import { Col, Container, FloatingLabel, Form, FormGroup, FormText, Row } from 'react-bootstrap';
import { Link, useNavigate } from "react-router-dom";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faEye, faEyeSlash } from '@fortawesome/free-solid-svg-icons';
import useForm from '../customHooks/useForm';
import './sass/_login.scss';

function Register() {
  const { values, errors, handleChange, handleSubmit, submitError } = useForm(registerUser);
  const [passwordVisible, setPasswordVisible] = useState(false);
  const navigate = useNavigate();

  function registerUser() {
    // setRegistered(true);
    navigate('/');
  }

  const togglePasswordVisibility = () => {
    setPasswordVisible(!passwordVisible);
  };

  return (
    <Container className="register_container">
      <Row className="justify-content-center">
        <Col md={6} className="register_container__column">
          <div>
            <h3 className="register_container__head">Register</h3>
            <Form onSubmit={handleSubmit} noValidate>
              <FormGroup>
                <FloatingLabel
                  className="form_label mb-3"
                  controlId="floatingInput"
                  label="Email address"
                >
                  <Form.Control
                    autoComplete="off"
                    type="email"
                    name="email"
                    placeholder="Email address"
                    onChange={handleChange}
                    value={values.email || ""}
                    isInvalid={!!errors.email}
                    required />
                </FloatingLabel>
                <FormText className="error_message">{errors.email}</FormText>
              </FormGroup>

              <FormGroup className="mt-3">
                <FloatingLabel className="form_label" controlId="floatingPassword" label="Password" style={{position:"relative"}}> 
                  <Form.Control
                    type={passwordVisible ? "text" : "password"}
                    name="password"
                    placeholder="Password"
                    onChange={handleChange}
                    value={values.password || ""}
                    isInvalid={!!errors.password}
                    style={{position:"relative"}}
                    required />
                    <div className="password-toggle-icon" data-testid="visbility-icon" onClick={togglePasswordVisibility} style={{position:'absolute',right:'20px',top:"20px"}}>
                    <FontAwesomeIcon icon={passwordVisible ? faEye : faEyeSlash} />
                  </div>
                </FloatingLabel>
                <FormText className="error_message">{errors.password}</FormText>
              </FormGroup>
              <div className="navigate_links mt-2 justify-content-end">
                <Link to="/"><span>Already have an account</span></Link>
              </div>
              <div className="text-center mt-3">
                <button data-testid="signin-btn" type="submit">
                  Signin
                </button>
              </div>
              {submitError && <p className="error_message">{submitError}</p>}
            </Form>
          </div>
        </Col>
      </Row>
    </Container>
  )
}

export default Register;
