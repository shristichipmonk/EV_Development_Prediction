// SafetyNorms.js
import React from 'react';
import InfoTablee from '../Tables/InfoTable';
import '../Tables/_table.scss';
import { Normsdata } from '../../utils/NormsData';

const SafetyNorms = () => {
  const columns = [
    { Header: 'Norms ID', accessor: 'normsId' },
    { Header: 'Norms Name', accessor: 'normsName' }, 
    { Header: 'Description', accessor: 'description' },
    { Header: 'Severity', accessor: 'Severity' },
    { Header: 'Threshold values', accessor: 'Thresholdvalues' },
    { Header: 'Threshold Unit', accessor: 'ThresholdUnit' },
    { Header: 'Applied Component', accessor: 'AppliedComponent' },
    { Header: 'Frequency', accessor: 'Frequency' },
    { Header: 'Last Checked', accessor: 'LastChecked' },
  ];

  const fetchSafetyNorms = ()=>{
    return Normsdata;
  }
  


  return (
    <div className="safety_norms" style={{ 
             padding: '24px',
  }}>
      <h1>Safety Norms</h1>
      <InfoTablee columns={columns} fetchData={fetchSafetyNorms} />

    </div>
  );
};

export default SafetyNorms;
