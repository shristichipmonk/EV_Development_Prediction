import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Container, Form, FormGroup, FormText, Row, Col, FloatingLabel } from 'react-bootstrap';
import './sass/_login.scss';
import useForm from '../customHooks/useForm';
import { useAuth } from "../../Authprovider";

function Login() {
  const { values, errors, handleChange, handleSubmit,submitError } = useForm(userLogin);
  const [loggedIn, setLoggedIn] = useState(false);

  const navigate = useNavigate();
  const {isLoggedIn,login,} = useAuth();
  useEffect(()=>{
    if(isLoggedIn){
        navigate('/gpslocator')
    }
  },[])


    function userLogin() {
        setLoggedIn(true);
        login(values.email)
        // localStorage.setItem("email",values.email)
        // navigate('/gpslocator');
        navigate('/gpslocator');

    }

    return (
        <Container className="login_container">
            <Row className="justify-content-center">
                <Col md={6} className="login_container__column">
                    <div>
                        <h3 className="login_container__head">LOGIN</h3>
                        <Form onSubmit={handleSubmit} noValidate>
                            <FormGroup>
                            <FloatingLabel
                                    className="form_label mb-3"
                                    controlId="floatingInput"
                                    label="Email address"
                            >
                                <Form.Control   
                                    autoComplete="off"
                                    type="email"
                                    name="email"
                                    placeholder="Email address"
                                    onChange={handleChange}
                                    value={values.email || ""}
                                    isInvalid={!!errors.email}
                                    required/>
                             </FloatingLabel>
                                <FormText className="error_message">{errors.email}</FormText>
                            </FormGroup>

                            <FormGroup className="mt-3">
                                  <FloatingLabel  className="form_label" controlId="floatingPassword" label="Password">
                                  <Form.Control                                   
                                    type="password"
                                    name="password"
                                    placeholder="Password"
                                    onChange={handleChange}
                                    value={values.password || ""}
                                    isInvalid={!!errors.password}
                                    required />
                              </FloatingLabel>
                                <FormText className="error_message">{errors.password}</FormText>
                            </FormGroup>
                            <div className="navigate_links mt-2">
                             <Link to="/forgotpassword">Forgot password</Link>
                             <Link to="/register">Create an account</Link>
                            </div>
                            <div className="text-center mt-3">
                              <button data-testid='login-btn'  type="submit" >
                                 Login
                              </button>
                            </div>
                            {submitError && <p className="error_message">{submitError}</p>}
                        </Form>
                    </div>
                </Col>
            </Row>
        </Container>
    );
}

export default Login;

