import React, { useState } from 'react';
import InfoTable from '../Tables/InfoTable'; 
import Tabs from '../Tabs';
import Swal from 'sweetalert2';
import { historicaldata } from '../actions'; // Importing API functions
import { format } from 'date-fns';

let selectedParameter = 'Select Parameter';
function BMS() {
  
  const [activeTab, setActiveTab] = useState(0);
  const [expandedrow, setExpandedRow] = useState(null);
  const [formData, setFormData] = useState({
    vehicle_id: '',
    parameter: '',
    start_time: null, // Initialize with current date
    end_time: null, // Initialize with current date
  });
  const [data, setData] = useState(null);
  const [filteredColumns,setfilteredColumns] = useState([]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    // Parse the date string into a Date object for start_time and end_time fields
    const dateValue = name === 'start_time' || name === 'end_time' ? value : value;
    setFormData({
      ...formData,
      [name]: dateValue
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!formData.vehicle_id.trim()) {
      await Swal.fire({
        icon: 'info',
        title: 'Please enter Vehicle ID',
        text: 'Vehicle ID cannot be empty',
      });
      return; // Exit the function
    } else if (!formData.parameter) {
      await Swal.fire({
        icon: 'info',
        title: 'Please select a parameter',
      });
      return; // Exit the function early if parameter is empty
    } else if (!formData.start_time) {
      console.error('No start time provided');
      await Swal.fire({
        icon: 'info',
        title: 'Please select a Start Time',
      });
      return; // Exit the function early if start time is empty
    } else if (!formData.end_time) {
      console.error('No end time provided');
      await Swal.fire({
        icon: 'info',
        title: 'Please select an End Time',
      });
      return; // Exit the function early if end time is empty
    } else if (new Date(formData.end_time) <= new Date(formData.start_time)) {
      // Show SweetAlert popup if end time is not greater than start time
      await Swal.fire({
        icon: 'info',
        title: 'End time should be greater than start time',
      });
      return; // Exit handleSubmit function
    }
  
    try {
      const selectedParameter = formData.parameter;
      const filtered_Columns_data = tabContents[activeTab].columns.filter(column => {
        if (selectedParameter === 'all') {
          return true; 
        } else if (selectedParameter === 'Latitude_Longitude') {
          return column.accessor === 'VehicleID' || column.accessor === 'BatteryID' || column.accessor === 'Updated_Time' || column.accessor === 'Latitude';
        } else {
          return column.accessor === 'VehicleID' || column.accessor === 'BatteryID' || column.accessor === 'Updated_Time' || column.accessor === selectedParameter;
        }
      });
  
      setfilteredColumns(filtered_Columns_data);
  
      const { vehicle_id, parameter, start_time, end_time } = formData;
      const result = await historicaldata(formData);
  
      if (result.data === 'No History Data Available' || result.data.length === 0) {
      // if (result.data.trim().toLowerCase() === 'no history data available') {
        // Show SweetAlert popup if data is 'No History Data Available'
        await Swal.fire({
          icon: 'info',
          title: 'No History Data Available',
        });
        return; // Exit handleSubmit function
      }
      
      setData(result.data);
    } catch (error) {
      console.error('Error fetching historical data:', error);
      // Handle error appropriately, such as displaying an error message to the user
    }
  };
  
  



  

  const changeTab = (index) => {
    setActiveTab(index);
  };

  // Tabs array
  const tabContents = [
    {
      title: "BMS",
      columns: [
        { Header: 'Vehicle Id', accessor: 'VehicleID' },
        { Header: 'Battery ID', accessor: 'BatteryID' },
        { Header: 'State Of Charge', accessor: 'State_Of_Charge' },
        { Header: 'Estimated Range ', accessor: 'EstimatedRange' },
        { Header: 'Remaining Range ', accessor: 'RemainingRange' },
        { Header: 'Interior Temperature ', accessor: 'InteriorTemperature' },
        { Header: 'Latitude and Longitude', accessor: 'Latitude' ,
        Cell: props => <div> 
       <div> {`Latitude: ${props.row.original.Latitude}`}</div>
       <div> {`Longitude: ${props.row.original.Longitude}`}</div>

      </div>
      },
        { Header: 'Longitude', accessor: 'Longitude' },
        { Header: 'Speed', accessor: 'Speed' },
        { Header: 'Voltage', accessor: 'Voltage' },
        { Header: 'Current ', accessor: 'Current' },
        { Header: 'Updated Time ', accessor: 'Updated_Time', Cell: ({ value }) => format(new Date(value), 'yyyy-MM-dd HH:mm:ss') },
      ],
      fetchDataFunction: async () => {
        try {
          const result = await historicaldata(formData);
          return result.data;
        } catch (error) {
          console.error('Error fetching historical data:', error);
          return [];
        }
      }
    }
  ];

  

  return (
    <div className="dashboard p-4">
      <h1 style={{ marginBottom: '20px' }}>Battery Management System</h1>
<form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
  <div style={{ marginBottom: '10px' }}>
    <label style={{ marginRight: '10px',marginLeft: '50px', fontWeight: 'bold' }}>Vehicle ID:</label>
    <input type="text" name="vehicle_id" value={formData.vehicle_id} onChange={handleChange} style={{ padding: '5px', borderRadius: '5px', border: '1px solid #ccc', marginTop: '10px' }} />
  </div>
  <div style={{ marginBottom: '10px', display: 'flex', alignItems: 'center' }}>
      <label style={{ marginRight: '10px', fontWeight: 'bold', minWidth: '100px' }}>Parameter:</label>
      <select name="parameter" value={formData.parameter} onChange={handleChange} style={{ padding: '5px', borderRadius: '5px', border: '1px solid #ccc', marginTop: '10px' }}>
        <option value="">Select Parameter</option>
        <option value="all">All</option>
        <option value="State_Of_Charge">State Of Charge</option>
        <option value="EstimatedRange">Estimated Range</option>
        <option value="RemainingRange">Remaining Range</option>
        <option value="InteriorTemperature">Interior Temperature</option>
        <option value="Latitude_Longitude">Latitude and Longitude</option>
        <option value="Speed">Speed</option>
        <option value="Voltage">Voltage</option>
        <option value="Current">Current</option>
        
       
        {/* Add more options as needed */}
      </select>
    </div>
  <div style={{ marginBottom: '10px' }}>
    <label style={{ marginRight: '10px', fontWeight: 'bold' }}>Start Time:</label>
    <input type="date" name="start_time" value={formData.start_time} onChange={handleChange} style={{ padding: '5px', borderRadius: '5px', border: '1px solid #ccc', marginTop: '10px' }} />
  </div>
  <div style={{ marginBottom: '10px' }}>
    <label style={{ marginRight: '10px', fontWeight: 'bold' }}>End Time:</label>
    <input type="date" name="end_time" value={formData.end_time} onChange={handleChange} style={{ padding: '5px', borderRadius: '5px', border: '1px solid #ccc', marginTop: '10px' }} />
  </div>
  <button type="submit" style={{ padding: '10px 20px', backgroundColor: '#007bff', color: '#fff', border: 'none', borderRadius: '5px', cursor: 'pointer', marginTop: '10px' }}>Submit</button>
</form>
{
  data  && (

        <Tabs
          tabs={tabContents.map((tab, index) => ({
            title: tab.title,
            content: <InfoTable columns={filteredColumns} data={data} expandedrow={expandedrow} setExpandedRow={setExpandedRow} />
          }))}
          activeTab={activeTab}
          onChangeTab={changeTab}
        />
      )}
    </div>
  );
}

export default BMS;

