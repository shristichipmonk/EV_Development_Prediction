import React, { useState } from 'react';
import InfoTablee from '../Tables/InfoTable';
// import Infotable from '../Tables/Infotable';
import Tabs from '../Tabs';
import { getBMSdetails, getSummaryInfo, getVehiclesInfo, getVehilcleHealth } from '../actions';

function Dashboard() {
  const [activeTab, setActiveTab] = useState(0);
  const [expandedrow, setExpandedRow] = useState(null);

  const changeTab = (index) => {
    setActiveTab(index);
  };

  const HandleRowClick = async (props) => {
    const vehicleID = props.row.original.VehicleId;
    const header = props.column.Header;
    let result;
    if (header == "BMS") {
     const data= await getBMSdetails(vehicleID);
     const {charging_profile:{ChargeRate,DischargeRate},
     telemetry:{InternalResistance}} = data;
     result = {
      "Charge Rate" : ChargeRate,
      "Discharge Rate" :  DischargeRate,
      "InternalResistance" :InternalResistance,
    }
    setExpandedRow({id:vehicleID,title: header, data : result});
    }
    else if (header == "Vehicle Health Parameters")
     {
      const {data} = await getVehilcleHealth(vehicleID);
      const { BrakeHealth, Suspension, SteeringAlignment, FluidLevel, AirFilter } = data[0];
      result = {
        "Brake Health" : BrakeHealth,
        "Suspension" :  Suspension,
        "Steering Alignment" : SteeringAlignment,
        "Fluid Level" : FluidLevel,
        "Air Filter"  : AirFilter
      }
      setExpandedRow({id:vehicleID, title: header, data : result});

    }
    else if (header == "Additional") {
      const {data} = await getVehilcleHealth(vehicleID);
      const {PowerSteering, RegenerativeBraking} = data[0];
      result = {
        "Power Steering" : PowerSteering,
        "Regenerative Braking" : RegenerativeBraking,
      }
      setExpandedRow({id:vehicleID, title: header, data : result});
    }
  }

  //Tabs array
  const tabContents = [
    {
      title: "Summary",
      columns: [
        {
          Header: 'Vehicle Id', accessor: 'VehicleId',
          Cell: props => <div>{props.value}</div>
        },
        {
          Header: 'Location (Lat/Long)', accessor: 'Location',
          Cell: ({ row }) => <div>{`(${row.original.LastKnownLatitude},${row.original.LastKnownLongitude} )`}</div>
        },
        {
          Header: 'Battery Status(%)', accessor: 'StateOfCharge',
          Cell: props => <div>{`${props.value} %`}</div>
        },
        { Header: 'Charging Status', accessor: 'ChargingStatus' },
        { Header: 'Speed', accessor: 'Speed' },
        { Header: 'Last Update', accessor: 'LastUpdateTime',
          Cell: props => <div>{`${new Date(props.value).toLocaleString()}`}</div>
        },
        {
          Header: 'Vehicle Status', accessor: '',
          Cell: ({ row }) => <div>{row.original.Speed > 0 ? "Moving" : "Stopped"}</div>
        },
      ],
      fetchDataFunction: async () => {
        const result = await getSummaryInfo();
        return result;
      },
    },

    {
      title: "Vehicle Details",
      columns: [
        {
          Header: 'Vehicle Id', accessor: 'VehicleId',
          Cell: props => <div>{props.value}</div>
        },
        {
          Header: 'Make', accessor: 'Make',
          Cell: props => <div>{`${props.value}`}</div>
        },
        {
          Header: 'Model', accessor: 'Model',
          Cell: props => <div>{`${props.value}`}</div>
        },
        {
          Header: 'BMS', accessor: 'StateOfCharge',
          Cell: props => {
            return (
              <div>
                <div>
                  {`1) State Of Charge: ${props.value} %`}
                </div>
                <div>
                  {`2) Voltage: ${props.row.original.BatteryVoltage}`}
                </div>
                <div>
                  {`3)Current: ${props.row.original.BatteryCurrent}`}
                </div>
                <div style={{ color: "#3ea5df", cursor:"pointer" }} onClick={() => HandleRowClick(props)}>Show More...</div>
              </div>)
          }
        },
        {
          Header: 'Alarms and Alerts', accessor: 'InteriorTemperature',
          Cell: ( props ) => {
            return (
              <div>
                <div>
                  {`1) Low Battery: ${props.row.original.StateOfCharge <= 50 ? "Yes" : "No"}`}
                </div>
                <div>
                  {`2) Over Heating: ${props.row.original.InteriorTemperature >= 45 ? "Yes" : "No"}`}
                </div>
              </div>
            )
          }

        },
        {
          Header: 'Vehicle Health Parameters', accessor: 'TirePressureFrontL',
          Cell: (props) => {
            return (
              <div>
                Tire Pressure(PSI):
                <div className="mx-2">
                  {`a)Front Left: ${props.row.original.TirePressureFrontL}`}
                </div>
                <div className="mx-2">
                  {`b)Front Right: ${props.row.original.TirePressureFrontR}`}
                </div>
                <div className="mx-2">
                  {`c)Rear Left: ${props.row.original.TirePressureRearL}`}
                </div>
                <div className="mx-2">
                  {`b)Rear Right: ${props.row.original.TirePressureRearR}`}
                </div>
                <div className="mx-2" style={{ color: "#3ea5df", cursor:"pointer" }}  onClick={() => HandleRowClick(props)}>Show More...</div>
              </div>)
          }
        },

        {
          Header: 'Additional', accessor: 'MotorHealth',
          Cell: (props) => {
            return (
              <div>
                <div>
                  {`1) Motor Health: ${props.row.original.MotorHealth}`}
                </div>
                <div>
                  {`2) Inverter Health: ${props.row.original.InverterHealth}`}
                </div>
                <div>
                  {`3) Wheel Alignment: ${props.row.original.WheelAlignment}`}
                </div>
                <div style={{ color: "#3ea5df",  cursor:"pointer" }}  onClick={() => HandleRowClick(props)}>Show More...</div>
              </div>
            )
          }
        },

      ],
      fetchDataFunction: async () => {
        const result = await getVehiclesInfo();
        return result;
      },
    }
  ]

  return (
    <div className="dashboard p-4">
      <h1>Dashboard</h1>
      <Tabs
        tabs={tabContents.map((tab, index) => ({ title: tab.title, content: <InfoTablee columns={tab.columns} fetchData={tab.fetchDataFunction} expandedrow={expandedrow} activeTab={activeTab} setExpandedRow={setExpandedRow} /> }))}
        activeTab={activeTab}
        onChangeTab={changeTab}
      />
    </div>
  )
}

export default Dashboard