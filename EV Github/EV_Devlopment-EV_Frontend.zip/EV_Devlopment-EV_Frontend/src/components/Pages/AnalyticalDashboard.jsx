import React from 'react';

function AnalyticalDashboard() {
  return (
    <h1>AnalyticalDashboard</h1>
  )
}

export default AnalyticalDashboard;