import { useLoadScript } from "@react-google-maps/api";
import React from 'react';
import Map from "../Map/Map";

function GpsLocater() {
    const { isLoaded } = useLoadScript({
        googleMapsApiKey: process.env.GOOGLE_API_KEY,
        libraries: ["places"],
      });
  return (
    <div>
      {(!isLoaded) ? <div>Loading...</div> : <Map />}
    </div>
  )
}

export default GpsLocater;