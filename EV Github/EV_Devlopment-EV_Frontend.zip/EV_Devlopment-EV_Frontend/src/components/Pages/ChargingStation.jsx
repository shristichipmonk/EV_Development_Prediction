import React, { useState } from 'react';

import InfoTablee from '../Tables/InfoTable'; // Correct the path if needed
import { getChargingStations } from '../actions';
import './../Tables/_table.scss';

const ChargingStation = () => {
  const [chargingStations, setChargingStations] = useState([]);

 
  // Define your table columns
  const columns = [
    { Header: 'ID', accessor: 'Id' },
    { Header: 'Name', accessor: 'Name' },
    { Header: 'Latitude', accessor: 'Latitude' },
    { Header: 'Longitude', accessor: 'Longitude' },
    { Header: 'Power Available', accessor: 'Power_Available' },
    { Header: 'Number of Docks', accessor: 'Num_Docks' },
  ];

  const fetchData = async () => {
    const result = await getChargingStations();
    return result;
  };

  return (
    <div className="charing_Stations" style={{ padding: '24px' }}>
      <h1>Charging Stations</h1>
      <InfoTablee columns={columns} fetchData={fetchData} />
    </div>
  );
};

export default ChargingStation;
