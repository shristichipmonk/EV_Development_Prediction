import React, { useState,useEffect } from 'react';
import './_otp.scss';
import { Link } from 'react-router-dom';

function OtpInput({otpLength}) {
  // states are not handled yet

  return (
    <div className="otp_cont">
        <div className="otp_cont__input">
            {
            Array(otpLength).fill(0).map((item,index)=>{
                return (
                    <div key={index} className="otp_cont__input__div">
                        <input></input>
                    </div>
                )
            })
           }
        </div>
        <p className="text-center text-secondary mt-3">If you don't recieve the code!  
            <Link> Resend</Link>
        </p>
        <div className="text-center mt-3" >
           <button>Verify and Proceed</button>
        </div>
    </div>
  )
}

export default OtpInput