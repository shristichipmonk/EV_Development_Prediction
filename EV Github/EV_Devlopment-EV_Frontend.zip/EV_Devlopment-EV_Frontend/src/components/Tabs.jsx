import React from 'react';
import './_tabs.scss';

const Tabs = ({ tabs, activeTab, onChangeTab }) => {
  return (
    <div className="tabs px-4">
      <div className="tab-buttons">
        {tabs.map((tab, index) => (
          <button style={{padding:"0.4rem"}}
            key={index}
            className={index === activeTab ? 'active' : ''}
            onClick={() => onChangeTab(index)}
          >
            {tab.title}
          </button>
        ))}
      </div>
      <div className="tab-content">
        {tabs[activeTab].content}
      </div>
    </div>
  );
};

export default Tabs;
