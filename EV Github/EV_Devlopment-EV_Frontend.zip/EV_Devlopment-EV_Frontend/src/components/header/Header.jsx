import { faBars, faXmark } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import React, { useEffect, useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useAuth } from '../../Authprovider';
import './_header.scss';

function Header() {
  // navTabs data
  const navItems = [
    { location: "/gpslocator", title: "GPS", id: "nav_gps" },
    { location: "/dashboard", title: "Dashboard", id: "nav_dashboard" },
    { location: "/analytical_dashboard", title: "Analytical Dashboard", id: "nav_analytical_dashboard" },
    { location: "/safetynorms", title: "Safety Norms", id: "nav_safety_norms" },
    { location: "/history", title: "Historical data", id: "nav_historical_data" },
    { location: "/ChargingStations", title: "Charging Stations", id: "nav_charging_stations" },

  ];

  // State variables
  const location = useLocation();
  const [menustatus, setMenuStatus] = useState(false);
  const [path, setPath] = useState(location.pathname);
  const [activeItem, setActiveItem] = useState(navItems[0].title);
  const [userStatus, setUserStatus] = useState(false);
  const { isLoggedIn } = useAuth();
  useEffect(() => {
    const email = localStorage.getItem('email');
    console.log("location", location)
    console.log("locationpath", location.pathname);
    setUserStatus(email ? true : false);
    console.log(location.pathname === '/' ? (email ? navItems[0].location : location.pathname) : location.pathname);
    setPath(location.pathname === '/' ? (email ? navItems[0].location : location.pathname) : location.pathname);
  }, [isLoggedIn]);

  return (
    <header className='header'>
      <div className='header__content'>
        <Link to="/"><h1 data-testid="logo" className='header__content_heading'>EV MS</h1></Link>
        <nav className={`header__content__nav ${menustatus ? "isMenu" : ""} `}>
          <ul>
            {isLoggedIn && (navItems.map((item) => {
              return (
                <li key={item.title} className={` ${path.includes(item.location) ? "active" : ""}`}>
                  <Link  data-testid={item.id} to={item.location} onClick={() => { setPath(item.location) }}>{item.title}</Link>
                </li>
              )
            }))}
          </ul>
        </nav>
        <div className="header__content__toggle" onClick={() => { setMenuStatus(!menustatus) }}>
          {menustatus ? <FontAwesomeIcon icon={faXmark} /> : <FontAwesomeIcon icon={faBars} />}
        </div>
      </div>
    </header>
  )
}

export default Header;
